-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 25, 2023 at 05:28 AM
-- Server version: 5.7.39
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jcubhomefinder`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2023-04-06 01:57:04', '2023-04-06 01:57:04', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/jcubhomefinder', 'yes'),
(2, 'home', 'http://localhost/jcubhomefinder', 'yes'),
(3, 'blogname', 'jcubhomefinder', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'phuclan.phan@my.jcu.edu.au', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:133:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:18:\"^profile/([^/]+)?$\";s:44:\"index.php?page_id=75&uwp_profile=$matches[1]\";s:19:\"^profile/([^/]+)/?$\";s:44:\"index.php?page_id=75&uwp_profile=$matches[1]\";s:32:\"^profile/([^/]+)/page/([0-9]+)?$\";s:62:\"index.php?page_id=75&uwp_profile=$matches[1]&paged=$matches[2]\";s:33:\"^profile/([^/]+)/page/([0-9]+)/?$\";s:62:\"index.php?page_id=75&uwp_profile=$matches[1]&paged=$matches[2]\";s:26:\"^profile/([^/]+)/([^/]+)?$\";s:64:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]\";s:27:\"^profile/([^/]+)/([^/]+)/?$\";s:64:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]\";s:40:\"^profile/([^/]+)/([^/]+)/page/([0-9]+)?$\";s:82:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]&paged=$matches[3]\";s:41:\"^profile/([^/]+)/([^/]+)/page/([0-9]+)/?$\";s:82:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]&paged=$matches[3]\";s:34:\"^profile/([^/]+)/([^/]+)/([^/]+)?$\";s:87:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]&uwp_subtab=$matches[3]\";s:35:\"^profile/([^/]+)/([^/]+)/([^/]+)/?$\";s:87:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]&uwp_subtab=$matches[3]\";s:48:\"^profile/([^/]+)/([^/]+)/([^/]+)/page/([0-9]+)?$\";s:105:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]&uwp_subtab=$matches[3]&paged=$matches[4]\";s:49:\"^profile/([^/]+)/([^/]+)/([^/]+)/page/([0-9]+)/?$\";s:105:\"index.php?page_id=75&uwp_profile=$matches[1]&uwp_tab=$matches[2]&uwp_subtab=$matches[3]&paged=$matches[4]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:39:\"testimonial/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"testimonial/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"testimonial/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"testimonial/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"testimonial/([^/]+)/embed/?$\";s:48:\"index.php?wpm-testimonial=$matches[1]&embed=true\";s:32:\"testimonial/([^/]+)/trackback/?$\";s:42:\"index.php?wpm-testimonial=$matches[1]&tb=1\";s:40:\"testimonial/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?wpm-testimonial=$matches[1]&paged=$matches[2]\";s:47:\"testimonial/([^/]+)/comment-page-([0-9]{1,})/?$\";s:55:\"index.php?wpm-testimonial=$matches[1]&cpage=$matches[2]\";s:36:\"testimonial/([^/]+)(?:/([0-9]+))?/?$\";s:54:\"index.php?wpm-testimonial=$matches[1]&page=$matches[2]\";s:28:\"testimonial/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"testimonial/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"testimonial/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"testimonial/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:61:\"testimonial-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:63:\"index.php?wpm-testimonial-category=$matches[1]&feed=$matches[2]\";s:56:\"testimonial-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:63:\"index.php?wpm-testimonial-category=$matches[1]&feed=$matches[2]\";s:37:\"testimonial-category/([^/]+)/embed/?$\";s:57:\"index.php?wpm-testimonial-category=$matches[1]&embed=true\";s:49:\"testimonial-category/([^/]+)/page/?([0-9]{1,})/?$\";s:64:\"index.php?wpm-testimonial-category=$matches[1]&paged=$matches[2]\";s:31:\"testimonial-category/([^/]+)/?$\";s:46:\"index.php?wpm-testimonial-category=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=26&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:32:\"(.?.+?)/edit-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&edit-password=$matches[3]\";s:31:\"(.?.+?)/edit-profile(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-profile=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:30:\"(.?.+?)/user-logout(/(.*))?/?$\";s:54:\"index.php?pagename=$matches[1]&user-logout=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:43:\"strong-testimonials/strong-testimonials.php\";i:1;s:39:\"user-registration/user-registration.php\";i:2;s:35:\"userswp-recaptcha/uwp-recaptcha.php\";i:3;s:35:\"userswp-social-login/uwp-social.php\";i:4;s:19:\"userswp/userswp.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'real-home', 'yes'),
(41, 'stylesheet', 'real-home', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '26', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '14', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1696298224', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:83:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:25:\"strong_testimonials_views\";b:1;s:26:\"strong_testimonials_fields\";b:1;s:27:\"strong_testimonials_options\";b:1;s:25:\"strong_testimonials_about\";b:1;s:24:\"manage_user_registration\";b:1;s:22:\"edit_user_registration\";b:1;s:22:\"read_user_registration\";b:1;s:24:\"delete_user_registration\";b:1;s:23:\"edit_user_registrations\";b:1;s:30:\"edit_others_user_registrations\";b:1;s:26:\"publish_user_registrations\";b:1;s:31:\"read_private_user_registrations\";b:1;s:25:\"delete_user_registrations\";b:1;s:33:\"delete_private_user_registrations\";b:1;s:35:\"delete_published_user_registrations\";b:1;s:32:\"delete_others_user_registrations\";b:1;s:31:\"edit_private_user_registrations\";b:1;s:33:\"edit_published_user_registrations\";b:1;s:30:\"manage_user_registration_terms\";b:1;s:28:\"edit_user_registration_terms\";b:1;s:30:\"delete_user_registration_terms\";b:1;s:30:\"assign_user_registration_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '26', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:94:\"<!-- wp:group -->\n<div class=\"wp-block-group\"><!-- wp:categories /--></div>\n<!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:10:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:0:{}s:14:\"subscribe-form\";a:0:{}s:16:\"footer-sidebar-1\";a:0:{}s:16:\"footer-sidebar-2\";a:0:{}s:16:\"footer-sidebar-3\";a:0:{}s:16:\"footer-sidebar-4\";a:0:{}s:16:\"footer-sidebar-5\";a:0:{}s:16:\"footer-sidebar-6\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:9:{i:1682053024;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1682085424;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1682085466;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1682128624;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1682128666;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1682128667;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1682647024;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1683895753;a:1:{s:24:\"wpchill_do_weekly_action\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_recent-posts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(121, 'recovery_keys', 'a:0:{}', 'yes'),
(124, 'theme_mods_twentytwentythree', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1681182604;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(127, 'https_detection_errors', 'a:1:{s:20:\"https_request_failed\";a:1:{i:0;s:21:\"HTTPS request failed.\";}}', 'yes'),
(135, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.2.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-6.2-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-6.2-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"6.2\";s:7:\"version\";s:3:\"6.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"6.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1682043192;s:15:\"version_checked\";s:3:\"6.2\";s:12:\"translations\";a:0:{}}', 'no'),
(138, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:26:\"phuclan.phan@my.jcu.edu.au\";s:7:\"version\";s:3:\"6.2\";s:9:\"timestamp\";i:1680746265;}', 'no'),
(146, 'can_compress_scripts', '1', 'no'),
(159, 'finished_updating_comment_type', '1', 'yes'),
(170, 'core_updater.lock', '1680747454', 'no'),
(171, 'recently_activated', 'a:1:{s:67:\"testimonial-slider-and-showcase/testimonial-slider-and-showcase.php\";i:1681261857;}', 'yes'),
(182, '_transient_health-check-site-status-result', '{\"good\":14,\"recommended\":7,\"critical\":0}', 'yes'),
(193, 'current_theme', 'Real Home', 'yes'),
(194, 'theme_mods_real-home', 'a:17:{i:0;b:0;s:29:\"real_home_front_page_elements\";a:4:{i:0;s:6:\"slider\";i:1;s:6:\"why-us\";i:2;s:4:\"blog\";i:3;s:7:\"clients\";}s:18:\"nav_menu_locations\";a:2:{s:12:\"primary-menu\";i:3;s:11:\"mobile-menu\";i:3;}s:18:\"custom_css_post_id\";i:-1;s:43:\"real_home_header_builder_controller_section\";s:363:\"{\"desktop\":{\"top\":{\"col-0\":[{\"id\":\"title_tagline\"}],\"col-1\":[{\"id\":\"primary_menu\"}],\"col-2\":[]},\"main\":{\"col-0\":[],\"col-1\":[],\"col-2\":[]},\"bottom\":{\"col-0\":[],\"col-1\":[],\"col-2\":[]}},\"mobile\":{\"top\":{\"col-0\":[],\"col-1\":[{\"id\":\"title_tagline\"}],\"col-2\":[{\"id\":\"toggle_menu\"}]},\"main\":{\"col-0\":[],\"col-1\":[],\"col-2\":[]},\"bottom\":{\"col-0\":[],\"col-1\":[],\"col-2\":[]}}}\";s:43:\"real_home_footer_builder_controller_section\";s:187:\"{\"desktop\":{\"top\":{\"col-0\":[],\"col-1\":[],\"col-2\":[]},\"main\":{\"col-0\":[],\"col-1\":[],\"col-2\":[]},\"bottom\":{\"col-0\":[{\"id\":\"footer_copyright\"}],\"col-1\":[],\"col-2\":[{\"id\":\"footer_social\"}]}}}\";s:22:\"real_home_social_icons\";a:2:{i:0;a:3:{s:7:\"network\";s:8:\"facebook\";s:4:\"icon\";s:0:\"\";s:4:\"link\";s:1:\"#\";}i:1;a:3:{s:7:\"network\";s:7:\"twitter\";s:4:\"icon\";s:0:\"\";s:4:\"link\";s:1:\"#\";}}s:39:\"real_home_front_page_clients_logo_lists\";a:0:{}s:22:\"real_home_accent_color\";a:2:{s:7:\"color_1\";s:14:\"rgb(1,113,187)\";s:7:\"color_2\";s:7:\"#354255\";}s:25:\"real_home_body_background\";a:6:{s:8:\"position\";s:8:\"top left\";s:10:\"attachment\";s:6:\"scroll\";s:6:\"repeat\";s:9:\"no-repeat\";s:4:\"size\";s:4:\"auto\";s:6:\"colors\";a:0:{}s:8:\"gradient\";a:0:{}}s:34:\"real_home_header_site_title_enable\";b:0;s:36:\"real_home_header_site_tagline_enable\";b:0;s:27:\"real_home_front_page_enable\";s:7:\"disable\";s:35:\"real_home_header_account_login_text\";s:14:\"Manage Account\";s:35:\"real_home_header_account_url_target\";a:1:{s:7:\"desktop\";s:4:\"true\";}s:31:\"real_home_header_account_border\";a:2:{s:5:\"width\";a:5:{s:6:\"side_1\";s:3:\"0px\";s:6:\"side_2\";s:3:\"0px\";s:6:\"side_3\";s:3:\"0px\";s:6:\"side_4\";s:3:\"0px\";s:6:\"linked\";s:2:\"on\";}s:6:\"colors\";a:0:{}}s:11:\"custom_logo\";i:113;}', 'yes'),
(195, 'theme_switched', '', 'yes'),
(197, 'real-home_transfer_slider', '1', 'yes'),
(217, 'category_children', 'a:0:{}', 'yes'),
(233, 'wpmtst_db_version', '1.0', 'no'),
(234, 'widget_strong-testimonials-view-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(235, 'strong-testimonials-rate-time', '1681346953', 'yes'),
(239, 'wpmtst_options', 'a:17:{s:11:\"embed_width\";s:0:\"\";s:8:\"nofollow\";b:1;s:8:\"noopener\";b:1;s:10:\"noreferrer\";b:1;s:15:\"disable_rewrite\";b:0;s:17:\"pending_indicator\";b:1;s:17:\"remove_whitespace\";b:1;s:16:\"support_comments\";b:0;s:21:\"support_custom_fields\";b:0;s:23:\"single_testimonial_slug\";s:11:\"testimonial\";s:9:\"scrolltop\";b:1;s:16:\"scrolltop_offset\";i:80;s:8:\"lazyload\";b:0;s:18:\"no_lazyload_plugin\";b:1;s:13:\"touch_enabled\";b:1;s:15:\"disable_upsells\";b:0;s:10:\"track_data\";b:0;}', 'yes'),
(240, 'wpmtst_fields', 'a:2:{s:10:\"field_base\";a:27:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:0:\"\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";}s:11:\"field_types\";a:3:{s:4:\"post\";a:3:{s:10:\"post_title\";a:29:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:0;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:17:\"Testimonial Title\";s:3:\"map\";s:10:\"post_title\";}s:12:\"post_content\";a:30:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:8:\"textarea\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:19:\"Testimonial Content\";s:3:\"map\";s:12:\"post_content\";s:4:\"core\";i:0;}s:14:\"featured_image\";a:29:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"file\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:14:\"Featured Image\";s:3:\"map\";s:14:\"featured_image\";}}s:6:\"custom\";a:4:{s:4:\"text\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:4:\"text\";}s:5:\"email\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:5:\"email\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:5:\"email\";}s:3:\"url\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:3:\"url\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:3:\"URL\";}s:8:\"checkbox\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:8:\"checkbox\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:1;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:8:\"checkbox\";}}s:8:\"optional\";a:4:{s:17:\"category-selector\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:17:\"category-selector\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:17:\"category selector\";}s:18:\"category-checklist\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:18:\"category-checklist\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:18:\"category checklist\";}s:9:\"shortcode\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:0;s:10:\"input_type\";s:9:\"shortcode\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:0;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:1;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:9:\"shortcode\";}s:6:\"rating\";a:28:{s:4:\"name\";s:0:\"\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:0:\"\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:6:\"rating\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:11:\"star rating\";}}}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(241, 'wpmtst_base_forms', 'a:2:{s:7:\"default\";a:4:{s:4:\"name\";s:7:\"default\";s:5:\"label\";s:12:\"Default Form\";s:8:\"readonly\";i:1;s:6:\"fields\";a:8:{i:0;a:29:{s:4:\"name\";s:11:\"client_name\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:9:\"Full Name\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:23:\"What is your full name?\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:4:\"text\";s:11:\"record_type\";s:6:\"custom\";}i:1;a:29:{s:4:\"name\";s:5:\"email\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:5:\"Email\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:5:\"email\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:27:\"What is your email address?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:5:\"email\";s:11:\"record_type\";s:6:\"custom\";}i:3;a:29:{s:4:\"name\";s:12:\"company_name\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:12:\"Company Name\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:26:\"What is your company name?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:4:\"text\";s:11:\"record_type\";s:6:\"custom\";}i:4;a:29:{s:4:\"name\";s:15:\"company_website\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:15:\"Company Website\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:3:\"url\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:33:\"Does your company have a website?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:3:\"URL\";s:11:\"record_type\";s:6:\"custom\";}i:5;a:30:{s:4:\"name\";s:10:\"post_title\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:7:\"Heading\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:32:\"A headline for your testimonial.\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:0;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:17:\"Testimonial Title\";s:3:\"map\";s:10:\"post_title\";s:11:\"record_type\";s:4:\"post\";}i:6;a:31:{s:4:\"name\";s:12:\"post_content\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:11:\"Testimonial\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:8:\"textarea\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:27:\"What do you think about us?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:19:\"Testimonial Content\";s:3:\"map\";s:12:\"post_content\";s:4:\"core\";i:0;s:11:\"record_type\";s:4:\"post\";}i:7;a:30:{s:4:\"name\";s:14:\"featured_image\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:5:\"Photo\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"file\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:34:\"Would you like to include a photo?\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:14:\"Featured Image\";s:3:\"map\";s:14:\"featured_image\";s:11:\"record_type\";s:4:\"post\";}i:8;a:29:{s:4:\"name\";s:11:\"star_rating\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:11:\"Star rating\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:6:\"rating\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:38:\"Would you like to include star rating?\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:11:\"star rating\";s:11:\"record_type\";s:8:\"optional\";}}}s:7:\"minimal\";a:4:{s:4:\"name\";s:7:\"minimal\";s:5:\"label\";s:12:\"Minimal Form\";s:8:\"readonly\";i:1;s:6:\"fields\";a:3:{i:0;a:29:{s:4:\"name\";s:11:\"client_name\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:4:\"Name\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:4:\"text\";s:11:\"record_type\";s:6:\"custom\";}i:1;a:29:{s:4:\"name\";s:5:\"email\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:5:\"Email\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:5:\"email\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:5:\"email\";s:11:\"record_type\";s:6:\"custom\";}i:2;a:31:{s:4:\"name\";s:12:\"post_content\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:11:\"Testimonial\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:8:\"textarea\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:19:\"Testimonial Content\";s:3:\"map\";s:12:\"post_content\";s:4:\"core\";i:0;s:11:\"record_type\";s:4:\"post\";}}}}', 'no'),
(242, 'wpmtst_custom_forms', 'a:1:{i:1;a:4:{s:4:\"name\";s:6:\"custom\";s:5:\"label\";s:11:\"Custom Form\";s:8:\"readonly\";i:0;s:6:\"fields\";a:8:{i:0;a:29:{s:4:\"name\";s:11:\"client_name\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:9:\"Full Name\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:23:\"What is your full name?\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:4:\"text\";s:11:\"record_type\";s:6:\"custom\";}i:1;a:29:{s:4:\"name\";s:5:\"email\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:5:\"Email\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:5:\"email\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:27:\"What is your email address?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:5:\"email\";s:11:\"record_type\";s:6:\"custom\";}i:3;a:29:{s:4:\"name\";s:12:\"company_name\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:12:\"Company Name\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:26:\"What is your company name?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:4:\"text\";s:11:\"record_type\";s:6:\"custom\";}i:4;a:29:{s:4:\"name\";s:15:\"company_website\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:15:\"Company Website\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:3:\"url\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:33:\"Does your company have a website?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:3:\"URL\";s:11:\"record_type\";s:6:\"custom\";}i:5;a:30:{s:4:\"name\";s:10:\"post_title\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:7:\"Heading\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"text\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:32:\"A headline for your testimonial.\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:0;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:17:\"Testimonial Title\";s:3:\"map\";s:10:\"post_title\";s:11:\"record_type\";s:4:\"post\";}i:6;a:31:{s:4:\"name\";s:12:\"post_content\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:11:\"Testimonial\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:8:\"textarea\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:1;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:1;s:6:\"before\";s:0:\"\";s:5:\"after\";s:27:\"What do you think about us?\";s:11:\"admin_table\";i:0;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:0;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:1;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:19:\"Testimonial Content\";s:3:\"map\";s:12:\"post_content\";s:4:\"core\";i:0;s:11:\"record_type\";s:4:\"post\";}i:7;a:30:{s:4:\"name\";s:14:\"featured_image\";s:12:\"name_mutable\";i:0;s:5:\"label\";s:5:\"Photo\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:4:\"file\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:0;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:34:\"Would you like to include a photo?\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:14:\"Featured Image\";s:3:\"map\";s:14:\"featured_image\";s:11:\"record_type\";s:4:\"post\";}i:8;a:29:{s:4:\"name\";s:11:\"star_rating\";s:12:\"name_mutable\";i:1;s:5:\"label\";s:11:\"Star rating\";s:10:\"show_label\";i:1;s:10:\"input_type\";s:6:\"rating\";s:12:\"action_input\";s:0:\"\";s:13:\"action_output\";s:0:\"\";s:4:\"text\";s:0:\"\";s:16:\"show_text_option\";i:0;s:8:\"required\";i:0;s:20:\"show_required_option\";i:1;s:18:\"default_form_value\";s:0:\"\";s:21:\"default_display_value\";s:0:\"\";s:20:\"show_default_options\";i:1;s:5:\"error\";s:23:\"This field is required.\";s:11:\"placeholder\";s:0:\"\";s:23:\"show_placeholder_option\";i:0;s:6:\"before\";s:0:\"\";s:5:\"after\";s:38:\"Would you like to include star rating?\";s:11:\"admin_table\";i:1;s:18:\"admin_table_option\";i:1;s:23:\"show_admin_table_option\";i:1;s:17:\"shortcode_on_form\";s:0:\"\";s:20:\"shortcode_on_display\";s:0:\"\";s:22:\"show_shortcode_options\";i:0;s:18:\"show_length_option\";i:0;s:10:\"max_length\";s:0:\"\";s:12:\"option_label\";s:11:\"star rating\";s:11:\"record_type\";s:8:\"optional\";}}}}', 'yes'),
(243, 'wpmtst_form_options', 'a:35:{s:11:\"post_status\";s:7:\"pending\";s:12:\"admin_notify\";b:0;s:15:\"customer-notify\";b:0;s:15:\"approved-notify\";b:0;s:24:\"sender_name_for_customer\";b:0;s:21:\"sender_customer_email\";b:0;s:26:\"sender_site_customer_email\";b:1;s:33:\"sender_name_for_customer_approval\";b:0;s:35:\"sender_site_customer_approval_email\";b:1;s:21:\"sender_approval_email\";b:0;s:10:\"mail_queue\";b:0;s:11:\"sender_name\";s:14:\"jcubhomefinder\";s:17:\"sender_site_email\";b:1;s:12:\"sender_email\";s:0:\"\";s:10:\"recipients\";a:1:{i:0;a:4:{s:10:\"admin_name\";s:0:\"\";s:11:\"admin_email\";s:0:\"\";s:16:\"admin_site_email\";b:1;s:7:\"primary\";b:1;}}s:17:\"default_recipient\";a:2:{s:10:\"admin_name\";s:0:\"\";s:11:\"admin_email\";s:0:\"\";}s:13:\"email_subject\";s:30:\"New testimonial for %BLOGNAME%\";s:31:\"customer_approval_email_subject\";s:26:\"Testimonial for %BLOGNAME%\";s:22:\"customer_email_subject\";s:26:\"Testimonial for %BLOGNAME%\";s:13:\"email_message\";s:98:\"New testimonial submission for %BLOGNAME%. This is awaiting action from the website administrator.\";s:31:\"customer_approval_email_message\";s:57:\"Your testimonial was published for %BLOGNAME%. Thank you!\";s:22:\"customer_email_message\";s:110:\"Your testimonial was received  for %BLOGNAME% and awaiting approval from the website administrator. Thank you!\";s:8:\"messages\";a:4:{s:14:\"required-field\";a:4:{s:5:\"order\";i:1;s:11:\"description\";s:8:\"Required\";s:4:\"text\";s:8:\"Required\";s:7:\"enabled\";i:1;}s:18:\"form-submit-button\";a:3:{s:5:\"order\";i:2;s:11:\"description\";s:13:\"Submit Button\";s:4:\"text\";s:15:\"Add Testimonial\";}s:16:\"submission-error\";a:3:{s:5:\"order\";i:3;s:11:\"description\";s:16:\"Submission Error\";s:4:\"text\";s:48:\"There was a problem processing your testimonial.\";}s:18:\"submission-success\";a:3:{s:5:\"order\";i:4;s:11:\"description\";s:18:\"Submission Success\";s:4:\"text\";s:54:\"Thank you! Your testimonial is waiting to be approved.\";}}s:17:\"scrolltop_success\";b:1;s:24:\"scrolltop_success_offset\";i:80;s:15:\"scrolltop_error\";b:1;s:22:\"scrolltop_error_offset\";i:80;s:14:\"success_action\";s:7:\"message\";s:19:\"success_redirect_id\";s:0:\"\";s:20:\"success_redirect_url\";s:0:\"\";s:12:\"members_only\";b:0;s:20:\"members_only_message\";s:45:\"You need to be logged in to access this form.\";s:9:\"mailchimp\";b:0;s:17:\"mailchimp_message\";s:28:\"Subscribe to our newsletter.\";s:14:\"mailchimp_list\";s:0:\"\";}', 'yes'),
(244, 'wpmtst_compat_options', 'a:6:{s:12:\"page_loading\";s:0:\"\";s:9:\"prerender\";s:7:\"current\";s:4:\"ajax\";a:7:{s:6:\"method\";s:0:\"\";s:15:\"universal_timer\";d:0.5;s:14:\"observer_timer\";d:0.5;s:12:\"container_id\";s:4:\"page\";s:12:\"addednode_id\";s:7:\"content\";s:5:\"event\";s:0:\"\";s:6:\"script\";s:0:\"\";}s:10:\"controller\";a:1:{s:13:\"initialize_on\";s:13:\"documentReady\";}s:8:\"lazyload\";a:2:{s:7:\"enabled\";s:0:\"\";s:7:\"classes\";a:1:{i:0;a:2:{s:5:\"start\";s:0:\"\";s:6:\"finish\";s:0:\"\";}}}s:9:\"random_js\";b:0;}', 'yes'),
(245, 'wpmtst_view_options', 'a:7:{s:4:\"mode\";a:4:{s:7:\"display\";a:3:{s:4:\"name\";s:7:\"display\";s:5:\"label\";s:7:\"Display\";s:11:\"description\";s:46:\"Display your testimonials in a list or a grid.\";}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:5:\"label\";s:9:\"Slideshow\";s:11:\"description\";s:40:\"Create a slideshow of your testimonials.\";}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:5:\"label\";s:4:\"Form\";s:11:\"description\";s:38:\"Display a testimonial submission form.\";}s:15:\"single_template\";a:3:{s:4:\"name\";s:15:\"single_template\";s:5:\"label\";s:15:\"Single Template\";s:11:\"description\";s:71:\"When viewing the testimonial using a theme&#039;s single post template.\";}}s:5:\"order\";a:4:{s:6:\"random\";s:6:\"random\";s:10:\"menu_order\";s:10:\"menu order\";s:6:\"newest\";s:12:\"newest first\";s:6:\"oldest\";s:12:\"oldest first\";}s:16:\"slideshow_effect\";a:4:{s:4:\"none\";s:20:\"no transition effect\";s:4:\"fade\";s:4:\"fade\";s:10:\"horizontal\";s:19:\"scroll horizontally\";s:8:\"vertical\";s:17:\"scroll vertically\";}s:16:\"slideshow_height\";a:2:{s:7:\"dynamic\";s:28:\"Adjust height for each slide\";s:6:\"static\";s:37:\"Set height to match the tallest slide\";}s:20:\"slideshow_nav_method\";a:2:{s:8:\"controls\";a:4:{s:4:\"none\";a:2:{s:5:\"label\";s:4:\"none\";s:4:\"args\";a:3:{s:8:\"controls\";i:0;s:5:\"pager\";i:0;s:12:\"autoControls\";i:0;}}s:4:\"full\";a:4:{s:5:\"label\";s:36:\"Bottom: previous / play-pause / next\";s:5:\"class\";s:18:\"controls-type-full\";s:18:\"add_position_class\";i:1;s:4:\"args\";a:5:{s:5:\"pager\";i:0;s:12:\"autoControls\";i:1;s:19:\"autoControlsCombine\";i:1;s:14:\"fullSetButtons\";i:1;s:11:\"fullSetText\";i:1;}}s:6:\"simple\";a:4:{s:5:\"label\";s:23:\"Bottom: previous / next\";s:5:\"class\";s:20:\"controls-type-simple\";s:18:\"add_position_class\";i:1;s:4:\"args\";a:2:{s:8:\"controls\";i:1;s:12:\"autoControls\";i:0;}}s:5:\"sides\";a:4:{s:5:\"label\";s:22:\"Sides: previous / next\";s:5:\"class\";s:19:\"controls-type-sides\";s:18:\"add_position_class\";i:0;s:4:\"args\";a:4:{s:8:\"controls\";i:1;s:12:\"autoControls\";i:0;s:8:\"prevText\";s:0:\"\";s:8:\"nextText\";s:0:\"\";}}}s:5:\"pager\";a:2:{s:4:\"none\";a:2:{s:5:\"label\";s:4:\"none\";s:4:\"args\";a:0:{}}s:4:\"full\";a:3:{s:5:\"label\";s:4:\"full\";s:5:\"class\";s:15:\"pager-type-full\";s:4:\"args\";a:1:{s:5:\"pager\";i:1;}}}}s:19:\"slideshow_nav_style\";a:2:{s:8:\"controls\";a:4:{s:7:\"buttons\";a:3:{s:5:\"label\";s:9:\"buttons 1\";s:5:\"class\";s:22:\"controls-style-buttons\";s:4:\"args\";a:4:{s:9:\"startText\";s:0:\"\";s:8:\"stopText\";s:0:\"\";s:8:\"prevText\";s:0:\"\";s:8:\"nextText\";s:0:\"\";}}s:8:\"buttons2\";a:3:{s:5:\"label\";s:9:\"buttons 2\";s:5:\"class\";s:23:\"controls-style-buttons2\";s:4:\"args\";a:4:{s:9:\"startText\";s:0:\"\";s:8:\"stopText\";s:0:\"\";s:8:\"prevText\";s:0:\"\";s:8:\"nextText\";s:0:\"\";}}s:8:\"buttons3\";a:3:{s:5:\"label\";s:9:\"buttons 3\";s:5:\"class\";s:23:\"controls-style-buttons3\";s:4:\"args\";a:4:{s:9:\"startText\";s:0:\"\";s:8:\"stopText\";s:0:\"\";s:8:\"prevText\";s:0:\"\";s:8:\"nextText\";s:0:\"\";}}s:4:\"text\";a:3:{s:5:\"label\";s:4:\"text\";s:5:\"class\";s:19:\"controls-style-text\";s:4:\"args\";a:4:{s:9:\"startText\";s:4:\"Play\";s:8:\"stopText\";s:5:\"Pause\";s:8:\"prevText\";s:8:\"Previous\";s:8:\"nextText\";s:4:\"Next\";}}}s:5:\"pager\";a:2:{s:7:\"buttons\";a:3:{s:5:\"label\";s:7:\"buttons\";s:5:\"class\";s:19:\"pager-style-buttons\";s:4:\"args\";a:2:{s:10:\"buildPager\";s:5:\"icons\";s:14:\"simpleSetPager\";i:1;}}s:4:\"text\";a:3:{s:5:\"label\";s:4:\"text\";s:5:\"class\";s:16:\"pager-style-text\";s:4:\"args\";a:2:{s:10:\"buildPager\";N;s:13:\"simpleSetText\";i:1;}}}}s:22:\"slideshow_nav_position\";a:2:{s:6:\"inside\";s:6:\"inside\";s:7:\"outside\";s:7:\"outside\";}}', 'yes'),
(246, 'wpmtst_view_default', 'a:51:{s:10:\"background\";a:5:{s:5:\"color\";s:0:\"\";s:4:\"type\";s:0:\"\";s:6:\"preset\";s:0:\"\";s:9:\"gradient1\";s:0:\"\";s:9:\"gradient2\";s:0:\"\";}s:8:\"category\";s:3:\"all\";s:5:\"class\";s:0:\"\";s:14:\"client_section\";a:2:{i:0;a:4:{s:5:\"field\";s:11:\"client_name\";s:4:\"type\";s:4:\"text\";s:6:\"before\";s:0:\"\";s:5:\"class\";s:16:\"testimonial-name\";}i:1;a:6:{s:5:\"field\";s:12:\"company_name\";s:4:\"type\";s:4:\"link\";s:6:\"before\";s:0:\"\";s:3:\"url\";s:15:\"company_website\";s:5:\"class\";s:19:\"testimonial-company\";s:7:\"new_tab\";b:1;}}s:12:\"column_count\";i:2;s:15:\"container_class\";s:0:\"\";s:14:\"container_data\";s:0:\"\";s:7:\"content\";s:6:\"entire\";s:5:\"count\";i:-1;s:12:\"divi_builder\";i:0;s:14:\"excerpt_length\";i:55;s:10:\"font-color\";a:2:{s:5:\"color\";s:0:\"\";s:4:\"type\";s:0:\"\";}s:9:\"form_ajax\";i:0;s:7:\"form_id\";i:1;s:8:\"gravatar\";s:2:\"no\";s:2:\"id\";s:0:\"\";s:17:\"initials_bg_color\";s:7:\"#ffffff\";s:19:\"initials_font_color\";s:7:\"#000000\";s:18:\"initials_font_size\";s:2:\"42\";s:6:\"layout\";s:0:\"\";s:9:\"less_post\";b:0;s:14:\"less_post_text\";s:9:\"Show less\";s:8:\"lightbox\";s:0:\"\";s:14:\"lightbox_class\";s:0:\"\";s:4:\"mode\";s:7:\"display\";s:14:\"more_full_post\";b:0;s:9:\"more_page\";b:0;s:14:\"more_page_hook\";s:18:\"wpmtst_view_footer\";s:12:\"more_page_id\";i:0;s:14:\"more_page_text\";s:22:\"Read more testimonials\";s:9:\"more_post\";b:1;s:18:\"more_post_ellipsis\";b:1;s:18:\"more_post_in_place\";b:0;s:14:\"more_post_text\";s:9:\"Read more\";s:4:\"note\";s:0:\"\";s:5:\"order\";s:6:\"oldest\";s:4:\"page\";s:0:\"\";s:10:\"pagination\";b:0;s:19:\"pagination_settings\";a:11:{s:4:\"type\";s:6:\"simple\";s:3:\"nav\";s:5:\"after\";s:8:\"per_page\";i:5;s:8:\"show_all\";i:0;s:8:\"end_size\";i:1;s:8:\"mid_size\";i:2;s:9:\"prev_next\";i:1;s:9:\"prev_text\";s:16:\"&laquo; Previous\";s:9:\"next_text\";s:12:\"Next &raquo;\";s:18:\"before_page_number\";s:0:\"\";s:17:\"after_page_number\";s:0:\"\";}s:18:\"slideshow_settings\";a:18:{s:4:\"type\";s:11:\"show_single\";s:11:\"show_single\";a:3:{s:10:\"max_slides\";i:1;s:11:\"move_slides\";i:1;s:6:\"margin\";i:1;}s:11:\"breakpoints\";a:4:{s:7:\"desktop\";a:5:{s:11:\"description\";s:7:\"Desktop\";s:5:\"width\";i:1200;s:10:\"max_slides\";i:2;s:11:\"move_slides\";i:1;s:6:\"margin\";i:20;}s:5:\"large\";a:5:{s:11:\"description\";s:5:\"Large\";s:5:\"width\";i:1024;s:10:\"max_slides\";i:2;s:11:\"move_slides\";i:1;s:6:\"margin\";i:20;}s:6:\"medium\";a:5:{s:11:\"description\";s:6:\"Medium\";s:5:\"width\";i:640;s:10:\"max_slides\";i:1;s:11:\"move_slides\";i:1;s:6:\"margin\";i:10;}s:5:\"small\";a:5:{s:11:\"description\";s:5:\"Small\";s:5:\"width\";i:480;s:10:\"max_slides\";i:1;s:11:\"move_slides\";i:1;s:6:\"margin\";i:1;}}s:6:\"effect\";s:4:\"fade\";s:5:\"speed\";i:1;s:5:\"pause\";i:8;s:10:\"auto_start\";b:1;s:18:\"continuous_sliding\";b:0;s:10:\"auto_hover\";b:1;s:12:\"adapt_height\";b:1;s:18:\"adapt_height_speed\";d:0.5;s:7:\"stretch\";i:0;s:18:\"stop_auto_on_click\";b:1;s:13:\"controls_type\";s:4:\"none\";s:14:\"controls_style\";s:7:\"buttons\";s:10:\"pager_type\";s:4:\"none\";s:11:\"pager_style\";s:7:\"buttons\";s:12:\"nav_position\";s:6:\"inside\";}s:8:\"template\";s:7:\"default\";s:17:\"template_settings\";a:0:{}s:9:\"thumbnail\";b:1;s:16:\"thumbnail_height\";N;s:14:\"thumbnail_size\";s:9:\"thumbnail\";s:15:\"thumbnail_width\";N;s:5:\"title\";b:1;s:10:\"title_link\";s:4:\"none\";s:18:\"use_default_length\";b:1;s:16:\"use_default_more\";b:0;s:4:\"view\";s:0:\"\";}', 'no'),
(247, 'wpmtst_history', 'a:2:{s:23:\"2.23.0_convert_nofollow\";s:19:\"2023-04-12 00:49:13\";s:23:\"2.28_new_update_process\";s:19:\"2023-04-12 00:49:13\";}', 'yes'),
(248, 'wpmtst_plugin_version', '3.1.3', 'yes'),
(249, 'wpmtst_update_log', 'a:1:{s:19:\"2023-04-12 00:49:13\";N;}', 'yes'),
(250, 'wpmtst_admin_notices', 'a:2:{s:15:\"feedback-notice\";a:1:{s:7:\"persist\";b:1;}s:13:\"upsell-notice\";a:1:{s:7:\"persist\";b:1;}}', 'no'),
(251, 'strong_testimonials_wisdom_notification_times', 'a:1:{s:19:\"strong-testimonials\";i:1681260553;}', 'yes'),
(252, 'strong_testimonials_wisdom_block_notice', 'a:1:{s:19:\"strong-testimonials\";s:19:\"strong-testimonials\";}', 'yes'),
(255, 'rttss_plugin_activation_time', '1681260575', 'yes'),
(257, 'tss_settings', 'a:4:{s:4:\"slug\";s:11:\"testimonial\";s:5:\"field\";a:6:{i:0;s:11:\"client_name\";i:1;s:11:\"project_url\";i:2;s:14:\"completed_date\";i:3;s:5:\"tools\";i:4;s:10:\"categories\";i:5;s:4:\"tags\";}s:11:\"form_fields\";a:6:{i:0;s:15:\"tss_designation\";i:1;s:11:\"tss_company\";i:2;s:12:\"tss_location\";i:3;s:10:\"tss_rating\";i:4;s:9:\"tss_video\";i:5;s:16:\"tss_social_media\";}s:18:\"notification_email\";s:26:\"phuclan.phan@my.jcu.edu.au\";}', 'yes'),
(258, 'widget_widget_tlp_port_owl_carousel', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(259, 'rttss_remind_me', '1681260734', 'yes'),
(260, 'rttss_spare_me', '2', 'yes'),
(262, 'wpm-testimonial-category_children', 'a:0:{}', 'yes'),
(273, 'user_registration_first_time_activation_flag', '', 'yes'),
(274, 'user_registration_default_form_page_id', '54', 'yes'),
(275, 'user_registration_version', '2.3.3.1', 'yes'),
(276, 'user_registration_db_version', '2.3.3.1', 'yes'),
(277, 'user_registration_activated', '2023-04-12', 'yes'),
(278, 'user_registration_updated_at', '2023-04-12', 'yes'),
(281, 'user_registration_admin_notices', 'a:1:{i:0;s:17:\"select_my_account\";}', 'yes'),
(282, 'ur_profile_picture_migrated', '1', 'yes'),
(284, 'user_registration_registration_page_id', '55', 'yes'),
(285, 'user_registration_myaccount_page_id', '56', 'yes'),
(286, 'user_registration_general_setting_login_options', 'admin_approval', 'yes'),
(287, 'user_registration_general_setting_disabled_user_roles', 'a:1:{i:0;s:10:\"subscriber\";}', 'yes'),
(288, 'user_registration_form_setting_enable_strong_password', 'yes', 'yes'),
(289, 'user_registration_form_setting_default_user_role', 'subscriber', 'yes'),
(290, 'user_registration_my_account_layout', 'vertical', 'yes'),
(291, 'user_registration_disable_profile_picture', 'no', 'yes'),
(292, 'user_registration_allow_usage_tracking', 'no', 'yes'),
(293, 'user_registration_form_setting_minimum_password_strength', '3', 'yes'),
(296, 'user_registration_users_listing_viewed', '2023-04-12 01:33:29', 'yes'),
(299, 'user_registration_date_box_1623051693_date_format', 'Y-m-d', 'yes'),
(300, 'user_registration_admin_notice_select_my_account', 'Please choose a <strong title=\"A page with [user_registration_my_account] shortcode\">My Account</strong> page in <a href=\"http://localhost/jcubhomefinder/wp-admin/admin.php?page=user-registration-settings#user_registration_myaccount_page_id\" style=\"text-decoration:none\">General Settings</a>. <br /><strong>Got Stuck? Read</strong> <a href=\"https://docs.wpeverest.com/user-registration/docs/how-to-show-account-profile/\" style=\"text-decoration:none\" target=\"_blank\">How to setup My Account page</a>.', 'yes'),
(305, 'uwp_settings', 'a:85:{s:13:\"register_page\";i:69;s:10:\"login_page\";i:70;s:12:\"account_page\";i:71;s:11:\"forgot_page\";i:72;s:10:\"reset_page\";i:73;s:11:\"change_page\";i:74;s:12:\"profile_page\";i:75;s:10:\"users_page\";i:76;s:19:\"user_list_item_page\";i:77;s:14:\"register_modal\";i:1;s:23:\"uwp_registration_action\";s:12:\"auto_approve\";s:20:\"wp_register_redirect\";i:1;s:11:\"login_modal\";i:1;s:17:\"login_redirect_to\";i:-1;s:14:\"block_wp_login\";i:0;s:14:\"disable_wp_2fa\";i:0;s:12:\"forgot_modal\";i:1;s:26:\"change_enable_old_password\";i:1;s:27:\"change_disable_password_nag\";i:0;s:21:\"enable_profile_header\";i:1;s:19:\"enable_profile_body\";i:1;s:19:\"profile_avatar_size\";s:0:\"\";s:19:\"profile_banner_size\";s:0:\"\";s:20:\"profile_banner_width\";i:1000;s:19:\"profile_no_of_items\";i:10;s:17:\"users_no_of_items\";i:10;s:23:\"uwp_disable_author_link\";i:0;s:20:\"users_default_layout\";s:4:\"3col\";s:25:\"author_box_enable_disable\";i:1;s:26:\"author_box_display_content\";s:13:\"below_content\";s:29:\"author_box_display_post_types\";a:1:{i:0;s:4:\"post\";}s:18:\"author_box_content\";s:0:\"\";s:20:\"author_box_bio_limit\";i:200;s:32:\"registration_success_email_admin\";i:1;s:40:\"registration_success_email_subject_admin\";s:40:\"[[#site_name#]] New account registration\";s:40:\"registration_success_email_content_admin\";s:77:\"Dear Admin,\n\nA user has been registered recently on your website.\n\n[#extras#]\";s:27:\"registration_activate_email\";i:1;s:35:\"registration_activate_email_subject\";s:44:\"[[#site_name#]] Please activate your account\";s:35:\"registration_activate_email_content\";s:113:\"Dear [#user_name#],\n\nThank you for signing up with [#site_name#]\n\n[#login_details#]\n\nThank you,\n[#site_name_url#]\";s:26:\"registration_success_email\";i:1;s:34:\"registration_success_email_subject\";s:35:\"[[#site_name#]] Your Log In Details\";s:34:\"registration_success_email_content\";s:151:\"Dear [#user_name#],\n\nYou can log in with the following information:\n\n[#login_details#]\n\nYou can login here: [#login_url#]\n\nThank you,\n[#site_name_url#]\";s:21:\"forgot_password_email\";i:1;s:29:\"forgot_password_email_subject\";s:33:\"[#site_name#] - Your new password\";s:29:\"forgot_password_email_content\";s:103:\"Dear [#user_name#],\n\n[#login_details#]\n\nYou can login here: [#login_url#]\n\nThank you,\n[#site_name_url#]\";s:21:\"change_password_email\";i:1;s:29:\"change_password_email_subject\";s:41:\"[#site_name#] - Password has been changed\";s:29:\"change_password_email_content\";s:130:\"Dear [#user_name#],\n\nYour password has been changed successfully.\n\nYou can login here: [#login_url#]\n\nThank you,\n[#site_name_url#]\";s:20:\"reset_password_email\";i:1;s:28:\"reset_password_email_subject\";s:39:\"[#site_name#] - Password has been reset\";s:28:\"reset_password_email_content\";s:115:\"Dear [#user_name#],\n\nYour password has been reset.\n\nYou can login here: [#login_url#]\n\nThank you,\n[#site_name_url#]\";s:20:\"account_update_email\";i:1;s:28:\"account_update_email_subject\";s:40:\"[#site_name#] - Account has been updated\";s:28:\"account_update_email_content\";s:94:\"Dear [#user_name#],\n\nYour account has been updated successfully.\n\nThank you,\n[#site_name_url#]\";s:20:\"account_delete_email\";i:1;s:28:\"account_delete_email_subject\";s:46:\"[#site_name#] - Your account has been deleted.\";s:28:\"account_delete_email_content\";s:94:\"Dear [#user_name#],\n\nYour account has been deleted successfully.\n\nThank you,\n[#site_name_url#]\";s:26:\"account_delete_email_admin\";i:1;s:34:\"account_delete_email_subject_admin\";s:51:\"[#site_name#] - Account has been deleted by a user.\";s:34:\"account_delete_email_content_admin\";s:105:\"Dear Admin,\n\nUser has deleted own account from the site.\n\n[#login_details#]\n\nThank you,\n[#site_name_url#]\";s:30:\"wp_new_user_notification_email\";i:1;s:38:\"wp_new_user_notification_email_subject\";s:29:\"[[#site_name#]] Login Details\";s:38:\"wp_new_user_notification_email_content\";s:152:\"Dear [#user_name#],\n\nTo set your password, visit the following address:\n\n[#reset_link#]\n\nYou can login here: [#login_url#]\n\nThank you,\n[#site_name_url#]\";s:34:\"account_new_email_activation_email\";i:1;s:42:\"account_new_email_activation_email_subject\";s:53:\"[#site_name#] - New email address activation required\";s:42:\"account_new_email_activation_email_content\";s:256:\"Dear [#user_name#],\n\nYou recently requested to change your email address. Please click on the following link to change it: [#new_email_link#]\n\nYou can safely ignore and delete this email if you do not want to take this action.\n\nThank you,\n[#site_name_url#]\";s:36:\"wp_new_user_notification_email_admin\";i:1;s:44:\"wp_new_user_notification_email_subject_admin\";s:37:\"[[#site_name#]] New User Registration\";s:44:\"wp_new_user_notification_email_content_admin\";s:139:\"Dear Admin,\n\nNew user registration on your site: [#site_name#]\n\nUsername: [#username#]\n\nEmail: [#user_email#]\n\nThank you,\n[#site_name_url#]\";s:21:\"user_post_counts_cpts\";a:1:{i:0;s:4:\"post\";}s:27:\"login_user_post_counts_cpts\";a:1:{i:0;s:4:\"post\";}s:27:\"multiple_registration_forms\";a:1:{i:0;a:9:{s:2:\"id\";i:1;s:5:\"title\";s:7:\"Default\";s:9:\"user_role\";s:10:\"subscriber\";s:10:\"reg_action\";s:12:\"auto_approve\";s:11:\"redirect_to\";i:-1;s:10:\"custom_url\";s:31:\"http://localhost/jcubhomefinder\";s:9:\"gdpr_page\";i:0;s:8:\"tos_page\";i:0;s:6:\"fields\";a:7:{s:10:\"first_name\";i:1;s:9:\"last_name\";i:2;s:8:\"username\";i:3;s:12:\"display_name\";i:4;s:5:\"email\";i:5;s:3:\"bio\";i:6;s:8:\"password\";i:7;}}}s:35:\"profile_seo_meta_description_length\";i:150;s:22:\"user_list_page_updated\";s:4:\"1100\";s:20:\"user_sorting_updated\";s:4:\"1230\";s:17:\"recaptcha_api_key\";s:0:\"\";s:20:\"recaptcha_api_secret\";s:0:\"\";s:33:\"enable_recaptcha_in_register_form\";s:1:\"1\";s:30:\"enable_recaptcha_in_login_form\";s:1:\"1\";s:31:\"enable_recaptcha_in_forgot_form\";s:1:\"1\";s:32:\"enable_recaptcha_in_account_form\";s:1:\"1\";s:33:\"enable_recaptcha_in_wp_login_form\";s:1:\"1\";s:36:\"enable_recaptcha_in_wp_register_form\";s:1:\"1\";s:15:\"recaptcha_title\";s:0:\"\";s:15:\"recaptcha_theme\";s:5:\"light\";}', 'yes'),
(307, 'uwp_default_data_installed', '1', 'yes'),
(310, 'uwp_db_version', '1.2.3.18', 'yes'),
(311, 'uwp_installed_on', '1681264260', 'yes'),
(312, 'widget_uwp_register', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(313, 'widget_uwp_forgot', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(314, 'widget_uwp_login', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(315, 'widget_uwp_change', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(316, 'widget_uwp_reset', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(317, 'widget_uwp_users', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(318, 'widget_uwp_users_item', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(319, 'widget_uwp_account', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(320, 'widget_uwp_profile', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(321, 'widget_uwp_profile_header', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(322, 'widget_uwp_profile_social', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(323, 'widget_uwp_profile_tabs', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(324, 'widget_uwp_profile_actions', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(325, 'widget_uwp_profile_section', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(326, 'widget_uwp_user_title', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(327, 'widget_uwp_user_avatar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(328, 'widget_uwp_user_cover', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(329, 'widget_uwp_user_post_counts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(330, 'widget_uwp_user_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(331, 'widget_uwp_users_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(332, 'widget_uwp_users_loop_actions', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(333, 'widget_uwp_users_loop', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(334, 'widget_uwp_user_actions', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(335, 'widget_uwp_output_location', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(336, 'widget_uwp_author_box', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(337, 'widget_uwp_button_group', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(338, 'widget_uwp_user_badge', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(347, 'uwp_social_db_version', '1.3.24', 'yes'),
(350, 'widget_uwp_social', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(355, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(392, 'site_logo', '113', 'yes'),
(397, '_transient_timeout_wp-font-awesome-settings-version', '1682215992', 'no'),
(398, '_transient_wp-font-awesome-settings-version', '6.4.0', 'no'),
(400, '_site_transient_timeout_theme_roots', '1682044993', 'no'),
(401, '_site_transient_theme_roots', 'a:4:{s:9:\"real-home\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";s:17:\"twentytwentythree\";s:7:\"/themes\";s:15:\"twentytwentytwo\";s:7:\"/themes\";}', 'no'),
(402, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1682043196;s:7:\"checked\";a:4:{s:9:\"real-home\";s:5:\"1.0.6\";s:15:\"twentytwentyone\";s:3:\"1.8\";s:17:\"twentytwentythree\";s:3:\"1.0\";s:15:\"twentytwentytwo\";s:3:\"1.3\";}s:8:\"response\";a:2:{s:17:\"twentytwentythree\";a:6:{s:5:\"theme\";s:17:\"twentytwentythree\";s:11:\"new_version\";s:3:\"1.1\";s:3:\"url\";s:47:\"https://wordpress.org/themes/twentytwentythree/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/theme/twentytwentythree.1.1.zip\";s:8:\"requires\";s:3:\"6.1\";s:12:\"requires_php\";s:3:\"5.6\";}s:15:\"twentytwentytwo\";a:6:{s:5:\"theme\";s:15:\"twentytwentytwo\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentytwo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentytwo.1.4.zip\";s:8:\"requires\";s:3:\"5.9\";s:12:\"requires_php\";s:3:\"5.6\";}}s:9:\"no_update\";a:2:{s:9:\"real-home\";a:6:{s:5:\"theme\";s:9:\"real-home\";s:11:\"new_version\";s:5:\"1.0.6\";s:3:\"url\";s:39:\"https://wordpress.org/themes/real-home/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/theme/real-home.1.0.6.zip\";s:8:\"requires\";s:3:\"5.6\";s:12:\"requires_php\";s:3:\"7.0\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.8.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(403, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1682043198;s:8:\"response\";a:2:{s:67:\"testimonial-slider-and-showcase/testimonial-slider-and-showcase.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:45:\"w.org/plugins/testimonial-slider-and-showcase\";s:4:\"slug\";s:31:\"testimonial-slider-and-showcase\";s:6:\"plugin\";s:67:\"testimonial-slider-and-showcase/testimonial-slider-and-showcase.php\";s:11:\"new_version\";s:5:\"2.3.2\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/testimonial-slider-and-showcase/\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/plugin/testimonial-slider-and-showcase.2.3.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:84:\"https://ps.w.org/testimonial-slider-and-showcase/assets/icon-256x256.gif?rev=2625008\";s:2:\"1x\";s:84:\"https://ps.w.org/testimonial-slider-and-showcase/assets/icon-128x128.gif?rev=2625008\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:87:\"https://ps.w.org/testimonial-slider-and-showcase/assets/banner-1544x500.png?rev=2620659\";s:2:\"1x\";s:86:\"https://ps.w.org/testimonial-slider-and-showcase/assets/banner-772x250.png?rev=2832876\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.5\";s:6:\"tested\";s:3:\"6.2\";s:12:\"requires_php\";b:0;}s:35:\"userswp-social-login/uwp-social.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:34:\"w.org/plugins/userswp-social-login\";s:4:\"slug\";s:20:\"userswp-social-login\";s:6:\"plugin\";s:35:\"userswp-social-login/uwp-social.php\";s:11:\"new_version\";s:6:\"1.3.25\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/userswp-social-login/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/userswp-social-login.1.3.25.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/userswp-social-login/assets/icon-256x256.png?rev=2730512\";s:2:\"1x\";s:73:\"https://ps.w.org/userswp-social-login/assets/icon-128x128.png?rev=2730512\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/userswp-social-login/assets/banner-1544x500.png?rev=2730512\";s:2:\"1x\";s:75:\"https://ps.w.org/userswp-social-login/assets/banner-772x250.png?rev=2730512\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";s:6:\"tested\";s:3:\"6.2\";s:12:\"requires_php\";b:0;}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"5.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:60:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=2818463\";s:2:\"1x\";s:60:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=2818463\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/akismet/assets/banner-1544x500.png?rev=2900731\";s:2:\"1x\";s:62:\"https://ps.w.org/akismet/assets/banner-772x250.png?rev=2900731\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582\";s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:43:\"strong-testimonials/strong-testimonials.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:33:\"w.org/plugins/strong-testimonials\";s:4:\"slug\";s:19:\"strong-testimonials\";s:6:\"plugin\";s:43:\"strong-testimonials/strong-testimonials.php\";s:11:\"new_version\";s:5:\"3.1.3\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/strong-testimonials/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/strong-testimonials.3.1.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/strong-testimonials/assets/icon-256x256.png?rev=2086584\";s:2:\"1x\";s:72:\"https://ps.w.org/strong-testimonials/assets/icon-256x256.png?rev=2086584\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:74:\"https://ps.w.org/strong-testimonials/assets/banner-772x250.png?rev=2086584\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.2\";}s:39:\"user-registration/user-registration.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:31:\"w.org/plugins/user-registration\";s:4:\"slug\";s:17:\"user-registration\";s:6:\"plugin\";s:39:\"user-registration/user-registration.php\";s:11:\"new_version\";s:7:\"2.3.3.1\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/user-registration/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/user-registration.2.3.3.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/user-registration/assets/icon-256x256.png?rev=2141788\";s:2:\"1x\";s:70:\"https://ps.w.org/user-registration/assets/icon-128x128.png?rev=2141788\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/user-registration/assets/banner-772x250.png?rev=2141793\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.0\";}s:19:\"userswp/userswp.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/userswp\";s:4:\"slug\";s:7:\"userswp\";s:6:\"plugin\";s:19:\"userswp/userswp.php\";s:11:\"new_version\";s:8:\"1.2.3.18\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/userswp/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/userswp.1.2.3.18.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:60:\"https://ps.w.org/userswp/assets/icon-256x256.png?rev=2784318\";s:2:\"1x\";s:60:\"https://ps.w.org/userswp/assets/icon-128x128.png?rev=2784318\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/userswp/assets/banner-1544x500.png?rev=2784318\";s:2:\"1x\";s:62:\"https://ps.w.org/userswp/assets/banner-772x250.png?rev=2784318\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:35:\"userswp-recaptcha/uwp-recaptcha.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:31:\"w.org/plugins/userswp-recaptcha\";s:4:\"slug\";s:17:\"userswp-recaptcha\";s:6:\"plugin\";s:35:\"userswp-recaptcha/uwp-recaptcha.php\";s:11:\"new_version\";s:6:\"1.3.18\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/userswp-recaptcha/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/userswp-recaptcha.1.3.18.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/userswp-recaptcha/assets/icon-256x256.png?rev=2730497\";s:2:\"1x\";s:70:\"https://ps.w.org/userswp-recaptcha/assets/icon-128x128.png?rev=2730497\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/userswp-recaptcha/assets/banner-1544x500.png?rev=2730497\";s:2:\"1x\";s:72:\"https://ps.w.org/userswp-recaptcha/assets/banner-772x250.png?rev=2730497\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:24:\"wpforms-lite/wpforms.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:26:\"w.org/plugins/wpforms-lite\";s:4:\"slug\";s:12:\"wpforms-lite\";s:6:\"plugin\";s:24:\"wpforms-lite/wpforms.php\";s:11:\"new_version\";s:7:\"1.8.1.2\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wpforms-lite/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wpforms-lite.1.8.1.2.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:57:\"https://ps.w.org/wpforms-lite/assets/icon.svg?rev=2574198\";s:3:\"svg\";s:57:\"https://ps.w.org/wpforms-lite/assets/icon.svg?rev=2574198\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wpforms-lite/assets/banner-1544x500.png?rev=2602491\";s:2:\"1x\";s:67:\"https://ps.w.org/wpforms-lite/assets/banner-772x250.png?rev=2602491\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/wpforms-lite/assets/banner-1544x500-rtl.png?rev=2602491\";s:2:\"1x\";s:71:\"https://ps.w.org/wpforms-lite/assets/banner-772x250-rtl.png?rev=2602491\";}s:8:\"requires\";s:3:\"5.2\";}}s:7:\"checked\";a:9:{s:19:\"akismet/akismet.php\";s:3:\"5.1\";s:9:\"hello.php\";s:5:\"1.7.2\";s:43:\"strong-testimonials/strong-testimonials.php\";s:5:\"3.1.3\";s:67:\"testimonial-slider-and-showcase/testimonial-slider-and-showcase.php\";s:5:\"2.3.1\";s:39:\"user-registration/user-registration.php\";s:7:\"2.3.3.1\";s:19:\"userswp/userswp.php\";s:8:\"1.2.3.18\";s:35:\"userswp-recaptcha/uwp-recaptcha.php\";s:6:\"1.3.18\";s:35:\"userswp-social-login/uwp-social.php\";s:6:\"1.3.24\";s:24:\"wpforms-lite/wpforms.php\";s:7:\"1.8.1.2\";}}', 'no'),
(404, '_site_transient_timeout_php_check_990bfacb848fa087bcfc06850f5e4447', '1682648000', 'no'),
(405, '_site_transient_php_check_990bfacb848fa087bcfc06850f5e4447', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 7, '_edit_lock', '1681252914:1'),
(6, 8, '_wp_attached_file', '2023/04/jcubhomefinder_background.png'),
(7, 8, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1842;s:6:\"height\";i:718;s:4:\"file\";s:37:\"2023/04/jcubhomefinder_background.png\";s:8:\"filesize\";i:1945938;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:37:\"jcubhomefinder_background-300x117.png\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:68357;}s:5:\"large\";a:5:{s:4:\"file\";s:38:\"jcubhomefinder_background-1024x399.png\";s:5:\"width\";i:1024;s:6:\"height\";i:399;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:600083;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:37:\"jcubhomefinder_background-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:44308;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:37:\"jcubhomefinder_background-768x299.png\";s:5:\"width\";i:768;s:6:\"height\";i:299;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:367380;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:38:\"jcubhomefinder_background-1536x599.png\";s:5:\"width\";i:1536;s:6:\"height\";i:599;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1162871;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(8, 7, '_wp_trash_meta_status', 'publish'),
(9, 7, '_wp_trash_meta_time', '1681252948'),
(15, 11, '_edit_lock', '1681253641:1'),
(21, 14, '_wp_attached_file', '2023/04/jcubhomefinder_site_icon.png'),
(22, 14, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:50;s:6:\"height\";i:50;s:4:\"file\";s:36:\"2023/04/jcubhomefinder_site_icon.png\";s:8:\"filesize\";i:527;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(23, 11, '_wp_trash_meta_status', 'publish'),
(24, 11, '_wp_trash_meta_time', '1681253644'),
(25, 15, '_edit_lock', '1681253831:1'),
(26, 15, '_wp_trash_meta_status', 'publish'),
(27, 15, '_wp_trash_meta_time', '1681253838'),
(28, 16, '_menu_item_type', 'custom'),
(29, 16, '_menu_item_menu_item_parent', '0'),
(30, 16, '_menu_item_object_id', '16'),
(31, 16, '_menu_item_object', 'custom'),
(32, 16, '_menu_item_target', ''),
(33, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(34, 16, '_menu_item_xfn', ''),
(35, 16, '_menu_item_url', 'http://localhost/jcubhomefinder/'),
(36, 16, '_menu_item_orphaned', '1681253895'),
(37, 2, '_wp_trash_meta_status', 'publish'),
(38, 2, '_wp_trash_meta_time', '1681253921'),
(39, 2, '_wp_desired_post_slug', 'sample-page'),
(40, 18, '_edit_lock', '1681259058:1'),
(41, 19, '_wp_trash_meta_status', 'publish'),
(42, 19, '_wp_trash_meta_time', '1681253965'),
(44, 22, '_wp_trash_meta_status', 'publish'),
(45, 22, '_wp_trash_meta_time', '1681254179'),
(46, 23, '_wp_trash_meta_status', 'publish'),
(47, 23, '_wp_trash_meta_time', '1681254201'),
(49, 1, '_wp_trash_meta_status', 'publish'),
(50, 1, '_wp_trash_meta_time', '1681254605'),
(51, 1, '_wp_desired_post_slug', 'hello-world'),
(52, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(53, 26, '_edit_lock', '1681345576:1'),
(64, 35, '_wp_attached_file', '2023/04/jcubhomepage_sampleimage1.jpg'),
(65, 35, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1094;s:6:\"height\";i:493;s:4:\"file\";s:37:\"2023/04/jcubhomepage_sampleimage1.jpg\";s:8:\"filesize\";i:109016;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:37:\"jcubhomepage_sampleimage1-300x135.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9781;}s:5:\"large\";a:5:{s:4:\"file\";s:38:\"jcubhomepage_sampleimage1-1024x461.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:461;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:59802;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:37:\"jcubhomepage_sampleimage1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5756;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:37:\"jcubhomepage_sampleimage1-768x346.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:346;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:39252;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(66, 36, '_wp_attached_file', '2023/04/jcubhomepage_sampleimage2.jpeg'),
(67, 36, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1024;s:6:\"height\";i:493;s:4:\"file\";s:38:\"2023/04/jcubhomepage_sampleimage2.jpeg\";s:8:\"filesize\";i:170047;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:38:\"jcubhomepage_sampleimage2-300x144.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:144;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8335;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:38:\"jcubhomepage_sampleimage2-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5359;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:38:\"jcubhomepage_sampleimage2-768x370.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:370;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29240;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(68, 38, '_edit_last', '1'),
(69, 38, '_edit_lock', '1681262137:1'),
(70, 39, '_wp_attached_file', '2023/04/testimonial-icon.png'),
(71, 39, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:730;s:6:\"height\";i:602;s:4:\"file\";s:28:\"2023/04/testimonial-icon.png\";s:8:\"filesize\";i:30926;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"testimonial-icon-300x247.png\";s:5:\"width\";i:300;s:6:\"height\";i:247;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:7962;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"testimonial-icon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4371;}s:16:\"widget-thumbnail\";a:5:{s:4:\"file\";s:26:\"testimonial-icon-75x75.png\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2054;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(72, 38, '_thumbnail_id', '39'),
(73, 38, 'client_name', 'Ramesh'),
(74, 38, 'email', 'ramesh@my.jcu.edu.au'),
(75, 38, 'company_name', ''),
(76, 38, 'company_website', ''),
(77, 38, 'nofollow', 'default'),
(78, 38, 'noopener', 'default'),
(79, 38, 'noreferrer', 'default'),
(80, 38, 'star_rating', '5'),
(81, 40, '_edit_last', '1'),
(82, 40, '_edit_lock', '1681261252:1'),
(83, 40, '_thumbnail_id', '39'),
(84, 40, 'tss_designation', ''),
(85, 40, 'tss_company', ''),
(86, 40, 'tss_location', ''),
(87, 40, 'tss_rating', '5'),
(88, 40, 'tss_video', ''),
(89, 40, 'tss_social_media', NULL),
(90, 43, '_edit_last', '1'),
(91, 43, '_edit_lock', '1681261755:1'),
(92, 43, '_thumbnail_id', '39'),
(93, 43, 'client_name', ''),
(94, 43, 'email', ''),
(95, 43, 'company_name', ''),
(96, 43, 'company_website', ''),
(97, 43, 'nofollow', 'default'),
(98, 43, 'noopener', 'default'),
(99, 43, 'noreferrer', 'default'),
(100, 43, 'star_rating', '5'),
(101, 44, '_edit_last', '1'),
(102, 44, '_edit_lock', '1681262095:1'),
(103, 44, 'client_name', ''),
(104, 44, 'email', ''),
(105, 44, 'company_name', ''),
(106, 44, 'company_website', ''),
(107, 44, 'nofollow', 'default'),
(108, 44, 'noopener', 'default'),
(109, 44, 'noreferrer', 'yes'),
(110, 44, 'star_rating', '5'),
(111, 44, '_thumbnail_id', '39'),
(113, 45, '_edit_lock', '1681262413:1'),
(114, 46, '_menu_item_type', 'custom'),
(115, 46, '_menu_item_menu_item_parent', '0'),
(116, 46, '_menu_item_object_id', '46'),
(117, 46, '_menu_item_object', 'custom'),
(118, 46, '_menu_item_target', ''),
(119, 46, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(120, 46, '_menu_item_xfn', ''),
(121, 46, '_menu_item_url', 'http://localhost/jcubhomefinder/'),
(122, 46, '_menu_item_orphaned', '1681262219'),
(123, 47, '_menu_item_type', 'post_type'),
(124, 47, '_menu_item_menu_item_parent', '0'),
(125, 47, '_menu_item_object_id', '26'),
(126, 47, '_menu_item_object', 'page'),
(127, 47, '_menu_item_target', ''),
(128, 47, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(129, 47, '_menu_item_xfn', ''),
(130, 47, '_menu_item_url', ''),
(131, 47, '_menu_item_orphaned', '1681262219'),
(132, 48, '_menu_item_type', 'custom'),
(133, 48, '_menu_item_menu_item_parent', '0'),
(134, 48, '_menu_item_object_id', '48'),
(135, 48, '_menu_item_object', 'custom'),
(136, 48, '_menu_item_target', ''),
(137, 48, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(138, 48, '_menu_item_xfn', ''),
(139, 48, '_menu_item_url', 'http://localhost/jcubhomefinder/'),
(140, 48, '_menu_item_orphaned', '1681262244'),
(141, 49, '_menu_item_type', 'post_type'),
(142, 49, '_menu_item_menu_item_parent', '0'),
(143, 49, '_menu_item_object_id', '26'),
(144, 49, '_menu_item_object', 'page'),
(145, 49, '_menu_item_target', ''),
(146, 49, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(147, 49, '_menu_item_xfn', ''),
(148, 49, '_menu_item_url', ''),
(149, 49, '_menu_item_orphaned', '1681262244'),
(150, 50, '_menu_item_type', 'post_type'),
(151, 50, '_menu_item_menu_item_parent', '0'),
(152, 50, '_menu_item_object_id', '26'),
(153, 50, '_menu_item_object', 'page'),
(154, 50, '_menu_item_target', ''),
(155, 50, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(156, 50, '_menu_item_xfn', ''),
(157, 50, '_menu_item_url', ''),
(158, 45, '_wp_trash_meta_status', 'publish'),
(159, 45, '_wp_trash_meta_time', '1681262415'),
(160, 51, '_edit_lock', '1681262833:1'),
(161, 51, '_wp_trash_meta_status', 'publish'),
(162, 51, '_wp_trash_meta_time', '1681262838'),
(163, 52, '_edit_lock', '1681263620:1'),
(164, 54, 'user_registration_form_setting_login_options', 'admin_approval'),
(165, 54, 'user_registration_form_setting_enable_strong_password', 'yes'),
(166, 54, 'user_registration_form_setting_default_user_role', 'subscriber'),
(167, 54, 'user_registration_form_setting_minimum_password_strength', '3'),
(168, 57, 'user_registration_imported_form_template_slug', 'user-registration-student-registration-form'),
(169, 57, 'user_registration_form_setting_login_options', 'default'),
(170, 57, 'user_registration_form_setting_default_user_role', 'subscriber'),
(171, 57, 'user_registration_form_setting_enable_strong_password', ''),
(172, 57, 'user_registration_form_setting_minimum_password_strength', '3'),
(173, 57, 'user_registration_form_setting_redirect_options', ''),
(174, 57, 'user_registration_form_setting_form_submit_class', ''),
(175, 57, 'user_registration_form_setting_form_submit_label', 'Submit'),
(176, 57, 'user_registration_form_setting_success_message_position', '1'),
(177, 57, 'user_registration_form_setting_enable_recaptcha_support', ''),
(178, 57, 'user_registration_form_template', 'Default'),
(179, 57, 'user_registration_form_custom_class', ''),
(180, 57, 'user_registration_form_setting_enable_assign_user_role_conditionally', '1'),
(181, 57, 'user_registration_social_connect_btn', ''),
(182, 57, 'user_registration_select_email_template', 'none'),
(183, 57, 'user_registration_form_setting_enable_reset_button', ''),
(184, 57, 'user_registration_form_setting_form_reset_class', ''),
(185, 57, 'user_registration_form_setting_form_reset_label', 'Reset'),
(186, 57, 'user_registration_enable_multipart', ''),
(187, 57, 'user_registration_multipart_indicator', 'progress'),
(188, 57, 'user_registration_multipart_indicator_color', '#475bb2'),
(189, 57, 'user_registration_multipart_nav_align', 'split'),
(190, 57, 'user_registration_enable_paypal_standard', ''),
(191, 57, 'user_registration_paypal_email_address', 'lekhnath005@gmail.com'),
(192, 57, 'user_registration_paypal_mode', 'production'),
(193, 57, 'user_registration_paypal_type', 'products'),
(194, 57, 'user_registration_paypal_cancel_url', 'https://wpeverest.me'),
(195, 57, 'user_registration_paypal_return_url', 'https://wpeverest.me/wp-login.php'),
(196, 57, 'user_registration_enable_stripe', ''),
(197, 57, 'user_registration_enable_stripe_recurring', ''),
(198, 57, 'user_registration_stripe_plan_name', ''),
(199, 57, 'user_registration_stripe_interval_count', ''),
(200, 57, 'user_registration_stripe_recurring_period', 'year'),
(201, 57, 'user_registration_enable_zapier', ''),
(202, 57, 'user_registration_zapier_webhook_url', ''),
(203, 57, 'user_registration_zapier_need_user_approval', ''),
(204, 57, 'user_registration_zapier_trigger_on_profile_update', ''),
(205, 57, 'user_registration_zapier_trigger_on_checkout', ''),
(206, 57, 'user_registration_multipart_parts', '[{\"id\":\"1\",\"name\":\"Part Title\",\"next\":\"Next\",\"prev\":\"Previous\",\"rows\":\"[1,2,3,4,5,6,7,8,10]\"}]'),
(207, 57, 'user_registration_mailerlite_integration', 's:312:\"a:5:{s:7:\"api_key\";s:32:\"4ea570b88caf1c6cf472a2153108bfa7\";s:11:\"list_fields\";s:2:\"{}\";s:12:\"double_optin\";s:5:\"false\";s:24:\"enable_conditional_logic\";s:5:\"false\";s:22:\"conditional_logic_data\";a:3:{s:17:\"conditional_field\";s:10:\"first_name\";s:20:\"conditional_operator\";s:2:\"is\";s:17:\"conditional_value\";s:0:\"\";}}\";'),
(208, 57, 'user_registration_user_role_condition', 's:434:\"a:1:{i:0;a:2:{s:11:\"assign_role\";s:13:\"administrator\";s:10:\"conditions\";a:1:{i:0;a:3:{i:0;a:2:{s:9:\"field_key\";s:45:\"user_registration_form_fields[condition_1][1]\";s:11:\"field_value\";s:19:\"textarea_1623050614\";}i:1;a:2:{s:9:\"field_key\";s:47:\"user_registration_form_operator[condition_1][1]\";s:11:\"field_value\";s:2:\"is\";}i:2;a:2:{s:9:\"field_key\";s:44:\"user_registration_form_value[condition_1][1]\";s:11:\"field_value\";s:6:\"butwal\";}}}}}\";'),
(209, 57, 'user_registration_pdf_submission_to_admin', ''),
(210, 57, 'user_registration_pdf_submission_to_user', ''),
(211, 57, 'user_registration_enable_field_icon', ''),
(212, 57, 'user_registration_learndash_courses', ''),
(213, 57, 'user_registration_paypal_conditional_integration', 's:60:\"a:1:{i:0;a:1:{s:24:\"enable_conditional_logic\";s:5:\"false\";}}\";'),
(214, 57, 'user_registration_stripe_conditional_integration', 's:60:\"a:1:{i:0;a:1:{s:24:\"enable_conditional_logic\";s:5:\"false\";}}\";'),
(215, 57, 'user_registration_form_setting_enable_email_approval', ''),
(216, 57, 'user_registration_enable_paypal_standard_subscription', ''),
(217, 57, 'user_registration_paypal_plan_name', ''),
(218, 57, 'user_registration_paypal_interval_count', ''),
(219, 57, 'user_registration_paypal_recurring_period', 'DAY'),
(220, 57, 'user_registration_enable_sync_fields_with_stripe', ''),
(221, 57, 'user_registration_stripe_sync_full_name', ''),
(222, 57, 'user_registration_stripe_sync_description', ''),
(223, 57, 'user_registration_stripe_sync_phone', ''),
(224, 57, 'user_registration_enable_sync_address_with_stripe', ''),
(225, 57, 'user_registration_stripe_sync_city', ''),
(226, 57, 'user_registration_stripe_sync_country', ''),
(227, 57, 'user_registration_stripe_sync_line1', ''),
(228, 57, 'user_registration_stripe_sync_line2', ''),
(229, 57, 'user_registration_stripe_sync_postal_code', ''),
(230, 57, 'user_registration_stripe_sync_state', ''),
(231, 57, 'user_registration_enable_sync_shipping_address_with_stripe', ''),
(232, 57, 'user_registration_stripe_sync_shipping_full_name', ''),
(233, 57, 'user_registration_stripe_sync_shipping_phone', ''),
(234, 57, 'user_registration_stripe_sync_shipping_city', ''),
(235, 57, 'user_registration_stripe_sync_shipping_country', ''),
(236, 57, 'user_registration_stripe_sync_shipping_line1', ''),
(237, 57, 'user_registration_stripe_sync_shipping_line2', ''),
(238, 57, 'user_registration_stripe_sync_shipping_postal_code', ''),
(239, 57, 'user_registration_stripe_sync_shipping_state', ''),
(240, 57, 'user_registration_form_row_ids', '[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\"]'),
(241, 57, 'user_registration_pro_auto_password_activate', ''),
(242, 57, 'user_registration_pro_auto_generated_password_length', '10'),
(243, 57, 'user_registration_pro_spam_protection_by_honeypot_enable', ''),
(244, 57, 'user_registration_mailchimp_integration', 's:6:\"a:0:{}\";'),
(245, 58, 'user_registration_imported_form_template_slug', 'user-registration-student-registration-form'),
(246, 58, 'user_registration_form_setting_login_options', 'default'),
(247, 58, 'user_registration_form_setting_default_user_role', 'subscriber'),
(248, 58, 'user_registration_form_setting_enable_strong_password', ''),
(249, 58, 'user_registration_form_setting_minimum_password_strength', '3'),
(250, 58, 'user_registration_form_setting_redirect_options', ''),
(251, 58, 'user_registration_form_setting_form_submit_class', ''),
(252, 58, 'user_registration_form_setting_form_submit_label', 'Submit'),
(253, 58, 'user_registration_form_setting_success_message_position', '1'),
(254, 58, 'user_registration_form_setting_enable_recaptcha_support', ''),
(255, 58, 'user_registration_form_template', 'Default'),
(256, 58, 'user_registration_form_custom_class', ''),
(257, 58, 'user_registration_form_setting_enable_assign_user_role_conditionally', '1'),
(258, 58, 'user_registration_social_connect_btn', ''),
(259, 58, 'user_registration_select_email_template', 'none'),
(260, 58, 'user_registration_form_setting_enable_reset_button', ''),
(261, 58, 'user_registration_form_setting_form_reset_class', ''),
(262, 58, 'user_registration_form_setting_form_reset_label', 'Reset'),
(263, 58, 'user_registration_enable_multipart', ''),
(264, 58, 'user_registration_multipart_indicator', 'progress'),
(265, 58, 'user_registration_multipart_indicator_color', '#475bb2'),
(266, 58, 'user_registration_multipart_nav_align', 'split'),
(267, 58, 'user_registration_enable_paypal_standard', ''),
(268, 58, 'user_registration_paypal_email_address', 'lekhnath005@gmail.com'),
(269, 58, 'user_registration_paypal_mode', 'production'),
(270, 58, 'user_registration_paypal_type', 'products'),
(271, 58, 'user_registration_paypal_cancel_url', 'https://wpeverest.me'),
(272, 58, 'user_registration_paypal_return_url', 'https://wpeverest.me/wp-login.php'),
(273, 58, 'user_registration_enable_stripe', ''),
(274, 58, 'user_registration_enable_stripe_recurring', ''),
(275, 58, 'user_registration_stripe_plan_name', ''),
(276, 58, 'user_registration_stripe_interval_count', ''),
(277, 58, 'user_registration_stripe_recurring_period', 'year'),
(278, 58, 'user_registration_enable_zapier', ''),
(279, 58, 'user_registration_zapier_webhook_url', ''),
(280, 58, 'user_registration_zapier_need_user_approval', ''),
(281, 58, 'user_registration_zapier_trigger_on_profile_update', ''),
(282, 58, 'user_registration_zapier_trigger_on_checkout', ''),
(283, 58, 'user_registration_multipart_parts', '[{\"id\":\"1\",\"name\":\"Part Title\",\"next\":\"Next\",\"prev\":\"Previous\",\"rows\":\"[1,2,3,4,5,6,7,8,10]\"}]'),
(284, 58, 'user_registration_mailerlite_integration', 's:312:\"a:5:{s:7:\"api_key\";s:32:\"4ea570b88caf1c6cf472a2153108bfa7\";s:11:\"list_fields\";s:2:\"{}\";s:12:\"double_optin\";s:5:\"false\";s:24:\"enable_conditional_logic\";s:5:\"false\";s:22:\"conditional_logic_data\";a:3:{s:17:\"conditional_field\";s:10:\"first_name\";s:20:\"conditional_operator\";s:2:\"is\";s:17:\"conditional_value\";s:0:\"\";}}\";'),
(285, 58, 'user_registration_user_role_condition', 's:434:\"a:1:{i:0;a:2:{s:11:\"assign_role\";s:13:\"administrator\";s:10:\"conditions\";a:1:{i:0;a:3:{i:0;a:2:{s:9:\"field_key\";s:45:\"user_registration_form_fields[condition_1][1]\";s:11:\"field_value\";s:19:\"textarea_1623050614\";}i:1;a:2:{s:9:\"field_key\";s:47:\"user_registration_form_operator[condition_1][1]\";s:11:\"field_value\";s:2:\"is\";}i:2;a:2:{s:9:\"field_key\";s:44:\"user_registration_form_value[condition_1][1]\";s:11:\"field_value\";s:6:\"butwal\";}}}}}\";'),
(286, 58, 'user_registration_pdf_submission_to_admin', ''),
(287, 58, 'user_registration_pdf_submission_to_user', ''),
(288, 58, 'user_registration_enable_field_icon', ''),
(289, 58, 'user_registration_learndash_courses', ''),
(290, 58, 'user_registration_paypal_conditional_integration', 's:60:\"a:1:{i:0;a:1:{s:24:\"enable_conditional_logic\";s:5:\"false\";}}\";'),
(291, 58, 'user_registration_stripe_conditional_integration', 's:60:\"a:1:{i:0;a:1:{s:24:\"enable_conditional_logic\";s:5:\"false\";}}\";'),
(292, 58, 'user_registration_form_setting_enable_email_approval', ''),
(293, 58, 'user_registration_enable_paypal_standard_subscription', ''),
(294, 58, 'user_registration_paypal_plan_name', ''),
(295, 58, 'user_registration_paypal_interval_count', ''),
(296, 58, 'user_registration_paypal_recurring_period', 'DAY'),
(297, 58, 'user_registration_enable_sync_fields_with_stripe', ''),
(298, 58, 'user_registration_stripe_sync_full_name', ''),
(299, 58, 'user_registration_stripe_sync_description', ''),
(300, 58, 'user_registration_stripe_sync_phone', ''),
(301, 58, 'user_registration_enable_sync_address_with_stripe', ''),
(302, 58, 'user_registration_stripe_sync_city', ''),
(303, 58, 'user_registration_stripe_sync_country', ''),
(304, 58, 'user_registration_stripe_sync_line1', ''),
(305, 58, 'user_registration_stripe_sync_line2', ''),
(306, 58, 'user_registration_stripe_sync_postal_code', ''),
(307, 58, 'user_registration_stripe_sync_state', ''),
(308, 58, 'user_registration_enable_sync_shipping_address_with_stripe', ''),
(309, 58, 'user_registration_stripe_sync_shipping_full_name', ''),
(310, 58, 'user_registration_stripe_sync_shipping_phone', ''),
(311, 58, 'user_registration_stripe_sync_shipping_city', ''),
(312, 58, 'user_registration_stripe_sync_shipping_country', ''),
(313, 58, 'user_registration_stripe_sync_shipping_line1', ''),
(314, 58, 'user_registration_stripe_sync_shipping_line2', ''),
(315, 58, 'user_registration_stripe_sync_shipping_postal_code', ''),
(316, 58, 'user_registration_stripe_sync_shipping_state', ''),
(317, 58, 'user_registration_form_row_ids', '[\"0\",\"1\",\"2\",\"3\",\"4\",\"7\"]'),
(318, 58, 'user_registration_pro_auto_password_activate', ''),
(319, 58, 'user_registration_pro_auto_generated_password_length', '10'),
(320, 58, 'user_registration_pro_spam_protection_by_honeypot_enable', ''),
(321, 58, 'user_registration_mailchimp_integration', 's:6:\"a:0:{}\";'),
(322, 55, '_edit_lock', '1681263609:1'),
(323, 18, '_wp_trash_meta_status', 'draft'),
(324, 18, '_wp_trash_meta_time', '1681263613'),
(325, 18, '_wp_desired_post_slug', ''),
(326, 62, '_menu_item_type', 'post_type'),
(327, 62, '_menu_item_menu_item_parent', '0'),
(328, 62, '_menu_item_object_id', '52'),
(329, 62, '_menu_item_object', 'page'),
(330, 62, '_menu_item_target', ''),
(331, 62, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(332, 62, '_menu_item_xfn', ''),
(333, 62, '_menu_item_url', ''),
(334, 61, '_wp_trash_meta_status', 'publish'),
(335, 61, '_wp_trash_meta_time', '1681263666'),
(336, 55, '_wp_trash_meta_status', 'publish'),
(337, 55, '_wp_trash_meta_time', '1681263674'),
(338, 55, '_wp_desired_post_slug', 'registration'),
(339, 64, '_wp_trash_meta_status', 'publish'),
(340, 64, '_wp_trash_meta_time', '1681263688'),
(341, 57, '_wp_trash_meta_status', 'publish'),
(342, 57, '_wp_trash_meta_time', '1681263743'),
(343, 57, '_wp_desired_post_slug', 'student-registration'),
(344, 54, '_wp_trash_meta_status', 'publish'),
(345, 54, '_wp_trash_meta_time', '1681263746'),
(346, 54, '_wp_desired_post_slug', 'default-form'),
(347, 65, '_edit_lock', '1681263870:1'),
(348, 65, '_wp_trash_meta_status', 'publish'),
(349, 65, '_wp_trash_meta_time', '1681263927'),
(350, 66, 'user_registration_imported_form_template_slug', 'blank'),
(351, 66, 'user_registration_form_setting_login_options', 'admin_approval'),
(352, 66, 'user_registration_form_setting_enable_email_approval', ''),
(353, 66, 'user_registration_form_setting_default_user_role', 'subscriber'),
(354, 66, 'user_registration_form_setting_enable_strong_password', '1'),
(355, 66, 'user_registration_form_setting_minimum_password_strength', '3'),
(356, 66, 'user_registration_form_setting_redirect_options', ''),
(357, 66, 'user_registration_form_setting_form_submit_class', ''),
(358, 66, 'user_registration_form_setting_form_submit_label', 'Submit'),
(359, 66, 'user_registration_form_setting_success_message_position', '1'),
(360, 66, 'user_registration_form_setting_enable_recaptcha_support', ''),
(361, 66, 'user_registration_form_template', 'Default'),
(362, 66, 'user_registration_form_custom_class', ''),
(363, 66, 'user_registration_form_row_ids', '[\"0\"]'),
(364, 56, '_edit_lock', '1681264021:1'),
(365, 66, '_wp_trash_meta_status', 'publish'),
(366, 66, '_wp_trash_meta_time', '1681264159'),
(367, 66, '_wp_desired_post_slug', 'login'),
(368, 77, 'uwp_1100_content', '[uwp_users_item]'),
(434, 95, '_menu_item_type', 'post_type'),
(435, 95, '_menu_item_menu_item_parent', '0'),
(436, 95, '_menu_item_object_id', '56'),
(437, 95, '_menu_item_object', 'page'),
(438, 95, '_menu_item_target', ''),
(439, 95, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(440, 95, '_menu_item_xfn', ''),
(441, 95, '_menu_item_url', ''),
(443, 96, '_menu_item_type', 'post_type'),
(444, 96, '_menu_item_menu_item_parent', '95'),
(445, 96, '_menu_item_object_id', '70'),
(446, 96, '_menu_item_object', 'page'),
(447, 96, '_menu_item_target', ''),
(448, 96, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(449, 96, '_menu_item_xfn', ''),
(450, 96, '_menu_item_url', ''),
(452, 97, '_menu_item_type', 'post_type'),
(453, 97, '_menu_item_menu_item_parent', '95'),
(454, 97, '_menu_item_object_id', '69'),
(455, 97, '_menu_item_object', 'page'),
(456, 97, '_menu_item_target', ''),
(457, 97, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(458, 97, '_menu_item_xfn', ''),
(459, 97, '_menu_item_url', ''),
(461, 98, '_edit_lock', '1681264782:1'),
(462, 100, '_edit_lock', '1681308660:1'),
(463, 102, '_menu_item_type', 'post_type'),
(464, 102, '_menu_item_menu_item_parent', '0'),
(465, 102, '_menu_item_object_id', '98'),
(466, 102, '_menu_item_object', 'page'),
(467, 102, '_menu_item_target', ''),
(468, 102, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(469, 102, '_menu_item_xfn', ''),
(470, 102, '_menu_item_url', ''),
(472, 103, '_menu_item_type', 'post_type'),
(473, 103, '_menu_item_menu_item_parent', '0'),
(474, 103, '_menu_item_object_id', '100'),
(475, 103, '_menu_item_object', 'page'),
(476, 103, '_menu_item_target', ''),
(477, 103, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(478, 103, '_menu_item_xfn', ''),
(479, 103, '_menu_item_url', ''),
(481, 104, '_wp_trash_meta_status', 'publish'),
(482, 104, '_wp_trash_meta_time', '1681264920'),
(483, 105, '_edit_lock', '1681265006:1'),
(484, 105, '_wp_trash_meta_status', 'publish'),
(485, 105, '_wp_trash_meta_time', '1681265031'),
(486, 109, '_edit_lock', '1681346462:1'),
(487, 103, '_wp_old_date', '2023-04-12'),
(488, 95, '_wp_old_date', '2023-04-12'),
(489, 96, '_wp_old_date', '2023-04-12'),
(490, 97, '_wp_old_date', '2023-04-12'),
(491, 112, '_menu_item_type', 'post_type'),
(492, 112, '_menu_item_menu_item_parent', '0'),
(493, 112, '_menu_item_object_id', '109'),
(494, 112, '_menu_item_object', 'page'),
(495, 112, '_menu_item_target', ''),
(496, 112, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(497, 112, '_menu_item_xfn', ''),
(498, 112, '_menu_item_url', ''),
(499, 111, '_wp_trash_meta_status', 'publish'),
(500, 111, '_wp_trash_meta_time', '1681346613'),
(501, 113, '_wp_attached_file', '2023/04/jcubhomefinder-logo.png'),
(502, 113, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:686;s:6:\"height\";i:364;s:4:\"file\";s:31:\"2023/04/jcubhomefinder-logo.png\";s:8:\"filesize\";i:67139;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:31:\"jcubhomefinder-logo-300x159.png\";s:5:\"width\";i:300;s:6:\"height\";i:159;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22360;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:31:\"jcubhomefinder-logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:15132;}s:16:\"widget-thumbnail\";a:5:{s:4:\"file\";s:29:\"jcubhomefinder-logo-75x75.png\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:6368;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(503, 114, '_wp_trash_meta_status', 'publish'),
(504, 114, '_wp_trash_meta_time', '1681349018');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-04-06 01:57:04', '2023-04-06 01:57:04', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2023-04-11 23:10:05', '2023-04-11 23:10:05', '', 0, 'http://localhost/jcubhomefinder/?p=1', 0, 'post', '', 1),
(2, 1, '2023-04-06 01:57:04', '2023-04-06 01:57:04', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/jcubhomefinder/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2023-04-11 22:58:41', '2023-04-11 22:58:41', '', 0, 'http://localhost/jcubhomefinder/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-04-06 01:57:04', '2023-04-06 01:57:04', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/jcubhomefinder.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2023-04-06 01:57:04', '2023-04-06 01:57:04', '', 0, 'http://localhost/jcubhomefinder/?page_id=3', 0, 'page', '', 0),
(6, 1, '2023-04-06 02:04:57', '2023-04-06 02:04:57', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentythree', '', '', '2023-04-06 02:04:57', '2023-04-06 02:04:57', '', 0, 'http://localhost/jcubhomefinder/2023/04/06/wp-global-styles-twentytwentythree/', 0, 'wp_global_styles', '', 0),
(7, 1, '2023-04-11 22:42:28', '2023-04-11 22:42:28', '{\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:36:03\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:36:03\"\n    },\n    \"real-home::real_home_accent_color\": {\n        \"value\": {\n            \"color_1\": \"rgb(1,113,187)\",\n            \"color_2\": \"#354255\"\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:36:03\"\n    },\n    \"real-home::real_home_body_background\": {\n        \"value\": {\n            \"image\": \"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png\",\n            \"position\": \"top left\",\n            \"attachment\": \"scroll\",\n            \"repeat\": \"no-repeat\",\n            \"size\": \"auto\",\n            \"colors\": [],\n            \"gradient\": []\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:41:54\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '1e5ba1dd-c355-4409-99b4-46ffc24e9917', '', '', '2023-04-11 22:42:28', '2023-04-11 22:42:28', '', 0, 'http://localhost/jcubhomefinder/?p=7', 0, 'customize_changeset', '', 0),
(8, 1, '2023-04-11 22:41:07', '2023-04-11 22:41:07', '', 'jcubhomefinder_background', '', 'inherit', 'open', 'closed', '', 'jcubhomefinder_background', '', '', '2023-04-11 22:41:07', '2023-04-11 22:41:07', '', 0, 'http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png', 0, 'attachment', 'image/png', 0),
(11, 1, '2023-04-11 22:54:04', '2023-04-11 22:54:04', '{\n    \"real-home::custom_logo\": {\n        \"value\": 13,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:46:28\"\n    },\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:44:50\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:44:50\"\n    },\n    \"real-home::real_home_header_site_title_enable\": {\n        \"value\": [],\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:46:58\"\n    },\n    \"real-home::real_home_header_site_tagline_enable\": {\n        \"value\": {\n            \"desktop\": \"true\"\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:46:58\"\n    },\n    \"site_icon\": {\n        \"value\": 14,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:54:04\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ecbeff00-0ee9-4fea-b5c3-cc5608ad3b16', '', '', '2023-04-11 22:54:04', '2023-04-11 22:54:04', '', 0, 'http://localhost/jcubhomefinder/?p=11', 0, 'customize_changeset', '', 0),
(14, 1, '2023-04-11 22:53:50', '2023-04-11 22:53:50', '', 'jcubhomefinder_site_icon', '', 'inherit', 'open', 'closed', '', 'jcubhomefinder_site_icon', '', '', '2023-04-11 22:53:50', '2023-04-11 22:53:50', '', 0, 'http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_site_icon.png', 0, 'attachment', 'image/png', 0),
(15, 1, '2023-04-11 22:57:18', '2023-04-11 22:57:18', '{\n    \"sidebars_widgets[sidebar-1]\": {\n        \"value\": [],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:57:11\"\n    },\n    \"widget_block[6]\": {\n        \"value\": {\n            \"raw_instance\": {\n                \"content\": \"<!-- wp:group -->\\n<div class=\\\"wp-block-group\\\"><!-- wp:categories /--></div>\\n<!-- /wp:group -->\"\n            }\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:56:06\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'a44d18c8-091f-4792-b285-420d328705d5', '', '', '2023-04-11 22:57:18', '2023-04-11 22:57:18', '', 0, 'http://localhost/jcubhomefinder/?p=15', 0, 'customize_changeset', '', 0),
(16, 1, '2023-04-11 22:58:15', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-04-11 22:58:15', '0000-00-00 00:00:00', '', 0, 'http://localhost/jcubhomefinder/?p=16', 1, 'nav_menu_item', '', 0),
(17, 1, '2023-04-11 22:58:41', '2023-04-11 22:58:41', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/jcubhomefinder/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2023-04-11 22:58:41', '2023-04-11 22:58:41', '', 2, 'http://localhost/jcubhomefinder/?p=17', 0, 'revision', '', 0),
(18, 1, '2023-04-12 01:40:13', '2023-04-12 01:40:13', '<!-- wp:cover {\"url\":\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png\",\"id\":8,\"dimRatio\":50,\"isDark\":false} -->\n<div class=\"wp-block-cover is-light\"><span aria-hidden=\"true\" class=\"wp-block-cover__background has-background-dim\"></span><img class=\"wp-block-cover__image-background wp-image-8\" alt=\"\" src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png\" data-object-fit=\"cover\"/><div class=\"wp-block-cover__inner-container\"><!-- wp:paragraph {\"align\":\"center\",\"placeholder\":\"Write title…\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-large-font-size\"></p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:cover -->', 'Student', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2023-04-12 01:40:13', '2023-04-12 01:40:13', '', 0, 'http://localhost/jcubhomefinder/?page_id=18', 0, 'page', '', 0),
(19, 1, '2023-04-11 22:59:25', '2023-04-11 22:59:25', '{\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:59:25\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:59:25\"\n    },\n    \"real-home::real_home_body_background\": {\n        \"value\": {\n            \"position\": \"top left\",\n            \"attachment\": \"scroll\",\n            \"repeat\": \"no-repeat\",\n            \"size\": \"auto\",\n            \"colors\": [],\n            \"gradient\": []\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 22:59:25\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '2b7211fb-9ac1-4c6c-9b51-eb655a16f1af', '', '', '2023-04-11 22:59:25', '2023-04-11 22:59:25', '', 0, 'http://localhost/jcubhomefinder/2023/04/11/2b7211fb-9ac1-4c6c-9b51-eb655a16f1af/', 0, 'customize_changeset', '', 0),
(20, 1, '2023-04-11 23:00:19', '2023-04-11 23:00:19', '', 'Nav', '', 'publish', 'closed', 'closed', '', 'nav', '', '', '2023-04-11 23:00:19', '2023-04-11 23:00:19', '', 0, 'http://localhost/jcubhomefinder/2023/04/11/nav/', 0, 'wp_navigation', '', 0),
(21, 1, '2023-04-11 23:00:54', '2023-04-11 23:00:54', '<!-- wp:cover {\"url\":\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png\",\"id\":8,\"dimRatio\":50,\"isDark\":false} -->\n<div class=\"wp-block-cover is-light\"><span aria-hidden=\"true\" class=\"wp-block-cover__background has-background-dim\"></span><img class=\"wp-block-cover__image-background wp-image-8\" alt=\"\" src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png\" data-object-fit=\"cover\"/><div class=\"wp-block-cover__inner-container\"><!-- wp:paragraph {\"align\":\"center\",\"placeholder\":\"Write title…\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-large-font-size\"></p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:cover -->', 'Student', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-04-11 23:00:54', '2023-04-11 23:00:54', '', 18, 'http://localhost/jcubhomefinder/?p=21', 0, 'revision', '', 0),
(22, 1, '2023-04-11 23:02:59', '2023-04-11 23:02:59', '{\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 23:02:59\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 23:02:59\"\n    },\n    \"real-home::real_home_body_background\": {\n        \"value\": {\n            \"image\": \"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder_background.png\",\n            \"position\": \"top left\",\n            \"attachment\": \"scroll\",\n            \"repeat\": \"no-repeat\",\n            \"size\": \"auto\",\n            \"colors\": [],\n            \"gradient\": []\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 23:02:59\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'eef7fa45-0c77-4f93-8da2-6a9ef9cfef1e', '', '', '2023-04-11 23:02:59', '2023-04-11 23:02:59', '', 0, 'http://localhost/jcubhomefinder/2023/04/11/eef7fa45-0c77-4f93-8da2-6a9ef9cfef1e/', 0, 'customize_changeset', '', 0),
(23, 1, '2023-04-11 23:03:21', '2023-04-11 23:03:21', '{\n    \"real-home::real_home_body_background\": {\n        \"value\": {\n            \"position\": \"top left\",\n            \"attachment\": \"scroll\",\n            \"repeat\": \"no-repeat\",\n            \"size\": \"auto\",\n            \"colors\": [],\n            \"gradient\": []\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 23:03:21\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '225bb7af-b6d8-4a95-8cd0-e4ce5dc23477', '', '', '2023-04-11 23:03:21', '2023-04-11 23:03:21', '', 0, 'http://localhost/jcubhomefinder/2023/04/11/225bb7af-b6d8-4a95-8cd0-e4ce5dc23477/', 0, 'customize_changeset', '', 0),
(25, 1, '2023-04-11 23:10:05', '2023-04-11 23:10:05', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2023-04-11 23:10:05', '2023-04-11 23:10:05', '', 1, 'http://localhost/jcubhomefinder/?p=25', 0, 'revision', '', 0),
(26, 1, '2023-04-12 00:28:02', '2023-04-12 00:28:02', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":35,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1-1024x461.jpg\" alt=\"\" class=\"wp-image-35\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":36,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage2.jpeg\" alt=\"\" class=\"wp-image-36\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":35,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1-1024x461.jpg\" alt=\"\" class=\"wp-image-35\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:strongtestimonials/view {\"id\":1} /-->', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2023-04-12 13:48:26', '2023-04-12 13:48:26', '', 0, 'http://localhost/jcubhomefinder/?page_id=26', 0, 'page', '', 0),
(29, 1, '2023-04-12 00:24:16', '2023-04-12 00:24:16', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":27,\"width\":255,\"height\":169,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large is-resized\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage-1024x683.jpg\" alt=\"\" class=\"wp-image-27\" width=\"255\" height=\"169\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":28,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage2.jpeg\" alt=\"\" class=\"wp-image-28\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":27,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage-1024x683.jpg\" alt=\"\" class=\"wp-image-27\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'Home', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2023-04-12 00:24:16', '2023-04-12 00:24:16', '', 26, 'http://localhost/jcubhomefinder/?p=29', 0, 'revision', '', 0),
(31, 1, '2023-04-12 00:27:51', '2023-04-12 00:27:51', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":30,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1.jpg\" alt=\"\" class=\"wp-image-30\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":28,\"width\":254,\"height\":121,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full is-resized\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage2.jpeg\" alt=\"\" class=\"wp-image-28\" width=\"254\" height=\"121\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":30,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1.jpg\" alt=\"\" class=\"wp-image-30\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'Home', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2023-04-12 00:27:51', '2023-04-12 00:27:51', '', 26, 'http://localhost/jcubhomefinder/?p=31', 0, 'revision', '', 0),
(35, 1, '2023-04-12 00:37:58', '2023-04-12 00:37:58', '', 'jcubhomepage_sampleimage1', '', 'inherit', 'open', 'closed', '', 'jcubhomepage_sampleimage1', '', '', '2023-04-12 00:37:58', '2023-04-12 00:37:58', '', 26, 'http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2023-04-12 00:37:59', '2023-04-12 00:37:59', '', 'jcubhomepage_sampleimage2', '', 'inherit', 'open', 'closed', '', 'jcubhomepage_sampleimage2', '', '', '2023-04-12 00:37:59', '2023-04-12 00:37:59', '', 26, 'http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2023-04-12 00:47:22', '2023-04-12 00:47:22', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":35,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1-1024x461.jpg\" alt=\"\" class=\"wp-image-35\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":36,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage2.jpeg\" alt=\"\" class=\"wp-image-36\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":35,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1-1024x461.jpg\" alt=\"\" class=\"wp-image-35\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'Home', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2023-04-12 00:47:22', '2023-04-12 00:47:22', '', 26, 'http://localhost/jcubhomefinder/?p=37', 0, 'revision', '', 0),
(38, 1, '2023-04-12 00:59:48', '2023-04-12 00:59:48', 'Thank you for helping me to get a place. Loved the place.', 'New Home', '', 'publish', 'closed', 'closed', '', 'new-home', '', '', '2023-04-12 01:15:37', '2023-04-12 01:15:37', '', 0, 'http://localhost/jcubhomefinder/?post_type=wpm-testimonial&#038;p=38', 3, 'wpm-testimonial', '', 0),
(39, 1, '2023-04-12 00:59:04', '2023-04-12 00:59:04', '', 'testimonial-icon', '', 'inherit', 'open', 'closed', '', 'testimonial-icon', '', '', '2023-04-12 00:59:04', '2023-04-12 00:59:04', '', 38, 'http://localhost/jcubhomefinder/wp-content/uploads/2023/04/testimonial-icon.png', 0, 'attachment', 'image/png', 0),
(40, 1, '2023-04-12 01:00:52', '2023-04-12 01:00:52', 'Thank you for help me to get a place to settle. Loved the place.', 'New Home', '', 'publish', 'closed', 'closed', '', 'new-home', '', '', '2023-04-12 01:00:52', '2023-04-12 01:00:52', '', 0, 'http://localhost/jcubhomefinder/?post_type=testimonial&#038;p=40', 1, 'testimonial', '', 0),
(41, 1, '2023-04-12 01:00:52', '2023-04-12 01:00:52', 'Thank you for help me to get a place to settle. Loved the place.', 'New Home', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2023-04-12 01:00:52', '2023-04-12 01:00:52', '', 40, 'http://localhost/jcubhomefinder/?p=41', 0, 'revision', '', 0),
(43, 1, '2023-04-12 01:09:15', '2023-04-12 01:09:15', 'I was very desperate to find a new place for me to stay. I went looking everywhere but finally with the help of JCUB Home Finder I was able to get a place. Thank you so so much', 'My Second Home', '', 'publish', 'open', 'closed', '', 'my-second-home', '', '', '2023-04-12 01:09:15', '2023-04-12 01:09:15', '', 0, 'http://localhost/jcubhomefinder/?post_type=wpm-testimonial&#038;p=43', 2, 'wpm-testimonial', '', 0),
(44, 1, '2023-04-12 01:14:55', '2023-04-12 01:14:55', 'Getting a place was difficult for me until I found JCUB Home Finder. Very helpful and understanding people in getting a place under my budgets.', 'Life Saver', '', 'publish', 'open', 'closed', '', 'life-saver', '', '', '2023-04-12 01:14:55', '2023-04-12 01:14:55', '', 0, 'http://localhost/jcubhomefinder/?post_type=wpm-testimonial&#038;p=44', 1, 'wpm-testimonial', '', 0),
(45, 1, '2023-04-12 01:20:15', '2023-04-12 01:20:15', '{\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:16:41\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:16:41\"\n    },\n    \"nav_menu_item[-2108913862028411000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:18:31\"\n    },\n    \"nav_menu_item[-4689498694641885000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:18:31\"\n    },\n    \"nav_menu_item[-6907104408376458000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:19:31\"\n    },\n    \"nav_menu_item[-3770380265524976600]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:19:31\"\n    },\n    \"nav_menu_item[-3920134563083980000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:19:31\"\n    },\n    \"nav_menu_item[-1310085593016255500]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:19:31\"\n    },\n    \"nav_menu_item[-2871974410363504600]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:19:31\"\n    },\n    \"nav_menu_item[-5116882142556739000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:19:31\"\n    },\n    \"nav_menu_item[-7071138332169194000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:20:15\"\n    },\n    \"nav_menu_item[-2782214617395366000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:20:15\"\n    },\n    \"nav_menu_item[-3093603954843148300]\": {\n        \"value\": {\n            \"object_id\": 26,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"post_type\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/jcubhomefinder/home/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Home\",\n            \"nav_menu_term_id\": 3,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:20:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7d8ebbcd-e186-4bfd-a812-e6bfef46dfff', '', '', '2023-04-12 01:20:15', '2023-04-12 01:20:15', '', 0, 'http://localhost/jcubhomefinder/?p=45', 0, 'customize_changeset', '', 0),
(46, 1, '2023-04-12 01:16:59', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-04-12 01:16:59', '0000-00-00 00:00:00', '', 0, 'http://localhost/jcubhomefinder/?p=46', 1, 'nav_menu_item', '', 0),
(47, 1, '2023-04-12 01:16:59', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-04-12 01:16:59', '0000-00-00 00:00:00', '', 0, 'http://localhost/jcubhomefinder/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2023-04-12 01:17:24', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-04-12 01:17:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/jcubhomefinder/?p=48', 1, 'nav_menu_item', '', 0),
(49, 1, '2023-04-12 01:17:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-04-12 01:17:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/jcubhomefinder/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2023-04-12 02:00:40', '2023-04-12 01:20:15', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2023-04-12 02:00:40', '2023-04-12 02:00:40', '', 0, 'http://localhost/jcubhomefinder/2023/04/12/50/', 1, 'nav_menu_item', '', 0),
(51, 1, '2023-04-12 01:27:18', '2023-04-12 01:27:18', '{\n    \"real-home::real_home_header_site_title_enable\": {\n        \"value\": [],\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:21:31\"\n    },\n    \"blogdescription\": {\n        \"value\": \"\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:22:31\"\n    },\n    \"real-home::real_home_header_site_tagline_enable\": {\n        \"value\": [],\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:22:31\"\n    },\n    \"real-home::real_home_header_builder_controller_section\": {\n        \"value\": \"%7B%22desktop%22:%7B%22top%22:%7B%22col-0%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-1%22:%5B%7B%22id%22:%22primary_menu%22%7D%5D,%22col-2%22:%5B%7B%22id%22:%22search_icon%22%7D%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D,%22mobile%22:%7B%22top%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-2%22:%5B%7B%22id%22:%22toggle_menu%22%7D%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D%7D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:24:49\"\n    },\n    \"show_on_front\": {\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:26:49\"\n    },\n    \"page_on_front\": {\n        \"value\": \"26\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:26:49\"\n    },\n    \"page_for_posts\": {\n        \"value\": \"0\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:27:18\"\n    },\n    \"real-home::real_home_front_page_enable\": {\n        \"value\": \"disable\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:26:49\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'dbd0c514-2f99-400b-a822-e9b4d02ceea8', '', '', '2023-04-12 01:27:18', '2023-04-12 01:27:18', '', 0, 'http://localhost/jcubhomefinder/?p=51', 0, 'customize_changeset', '', 0),
(52, 1, '2023-04-12 01:28:03', '2023-04-12 01:28:03', '<!-- wp:shortcode -->\n[user_registration_form id=\"58\"]\n<!-- /wp:shortcode -->', 'Student', '', 'publish', 'closed', 'closed', '', 'student', '', '', '2023-04-12 01:40:37', '2023-04-12 01:40:37', '', 0, 'http://localhost/jcubhomefinder/?page_id=52', 0, 'page', '', 0),
(53, 1, '2023-04-12 01:28:03', '2023-04-12 01:28:03', '', 'Student', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2023-04-12 01:28:03', '2023-04-12 01:28:03', '', 52, 'http://localhost/jcubhomefinder/?p=53', 0, 'revision', '', 0),
(54, 1, '2023-04-12 01:30:59', '2023-04-12 01:30:59', '[[[{\"field_key\":\"user_login\",\"general_setting\":{\"label\":\"Username\",\"field_name\":\"user_login\",\"placeholder\":\"\",\"required\":\"yes\"},\"advance_setting\":{}},{\"field_key\":\"user_pass\",\"general_setting\":{\"label\":\"User Password\",\"field_name\":\"user_pass\",\"placeholder\":\"\",\"required\":\"yes\"},\"advance_setting\":{}}],[{\"field_key\":\"user_email\",\"general_setting\":{\"label\":\"User Email\",\"field_name\":\"user_email\",\"placeholder\":\"\",\"required\":\"yes\"},\"advance_setting\":{}},{\"field_key\":\"user_confirm_password\",\"general_setting\":{\"label\":\"Confirm Password\",\"field_name\":\"user_confirm_password\",\"placeholder\":\"\",\"required\":\"yes\"},\"advance_setting\":{}}]]]', 'Default form', '', 'trash', 'closed', 'closed', '', 'default-form__trashed', '', '', '2023-04-12 01:42:26', '2023-04-12 01:42:26', '', 0, 'http://localhost/jcubhomefinder/?post_type=user_registration&#038;p=54', 0, 'user_registration', '', 0),
(55, 1, '2023-04-12 01:32:17', '2023-04-12 01:32:17', '[user_registration_form id=\"54\"]', 'Registration', '', 'trash', 'closed', 'closed', '', 'registration__trashed', '', '', '2023-04-12 01:41:14', '2023-04-12 01:41:14', '', 0, 'http://localhost/jcubhomefinder/registration/', 0, 'page', '', 0),
(56, 1, '2023-04-12 01:32:17', '2023-04-12 01:32:17', '[user_registration_form id=\"66\"]', 'My Account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2023-04-12 01:47:23', '2023-04-12 01:47:23', '', 0, 'http://localhost/jcubhomefinder/my-account/', 0, 'page', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(57, 1, '2023-04-12 01:35:38', '2023-04-12 01:35:38', '[[[]],[[{\"field_key\":\"first_name\",\"general_setting\":{\"label\":\"First Name\",\"description\":\"\",\"field_name\":\"first_name\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-first-name\"},{\"field_key\":\"textarea\",\"general_setting\":{\"label\":\"Mailing Address\",\"description\":\"\",\"field_name\":\"textarea_1623050614\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-textarea\"},{\"field_key\":\"country\",\"general_setting\":{\"label\":\"Country\",\"description\":\"\",\"field_name\":\"country_1623050729\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"selected_countries\":[\"AF\",\"AX\",\"AL\",\"DZ\",\"AS\",\"AD\",\"AO\",\"AI\",\"AQ\",\"AG\",\"AR\",\"AM\",\"AW\",\"AU\",\"AT\",\"AZ\",\"BS\",\"BH\",\"BD\",\"BB\",\"BY\",\"BE\",\"PW\",\"BZ\",\"BJ\",\"BM\",\"BT\",\"BO\",\"BQ\",\"BA\",\"BW\",\"BV\",\"BR\",\"IO\",\"VG\",\"BN\",\"BG\",\"BF\",\"BI\",\"KH\",\"CM\",\"CA\",\"CV\",\"KY\",\"CF\",\"TD\",\"CL\",\"CN\",\"CX\",\"CC\",\"CO\",\"KM\",\"CG\",\"CD\",\"CK\",\"CR\",\"HR\",\"CU\",\"CW\",\"CY\",\"CZ\",\"DK\",\"DJ\",\"DM\",\"DO\",\"EC\",\"EG\",\"SV\",\"GQ\",\"ER\",\"EE\",\"ET\",\"FK\",\"FO\",\"FJ\",\"FI\",\"FR\",\"GF\",\"PF\",\"TF\",\"GA\",\"GM\",\"GE\",\"DE\",\"GH\",\"GI\",\"GR\",\"GL\",\"GD\",\"GP\",\"GU\",\"GT\",\"GG\",\"GN\",\"GW\",\"GY\",\"HT\",\"HM\",\"HN\",\"HK\",\"HU\",\"IS\",\"IN\",\"ID\",\"IR\",\"IQ\",\"IE\",\"IM\",\"IL\",\"IT\",\"CI\",\"JM\",\"JP\",\"JE\",\"JO\",\"KZ\",\"KE\",\"KI\",\"KW\",\"KG\",\"LA\",\"LV\",\"LB\",\"LS\",\"LR\",\"LY\",\"LI\",\"LT\",\"LU\",\"MO\",\"MK\",\"MG\",\"MW\",\"MY\",\"MV\",\"ML\",\"MT\",\"MH\",\"MQ\",\"MR\",\"MU\",\"YT\",\"MX\",\"FM\",\"MD\",\"MC\",\"MN\",\"ME\",\"MS\",\"MA\",\"MZ\",\"MM\",\"NA\",\"NR\",\"NP\",\"NL\",\"NC\",\"NZ\",\"NI\",\"NE\",\"NG\",\"NU\",\"NF\",\"MP\",\"KP\",\"NO\",\"OM\",\"PK\",\"PS\",\"PA\",\"PG\",\"PY\",\"PE\",\"PH\",\"PN\",\"PL\",\"PT\",\"PR\",\"QA\",\"RE\",\"RO\",\"RU\",\"RW\",\"BL\",\"SH\",\"KN\",\"LC\",\"MF\",\"SX\",\"PM\",\"VC\",\"SM\",\"ST\",\"SA\",\"SN\",\"RS\",\"SC\",\"SL\",\"SG\",\"SK\",\"SI\",\"SB\",\"SO\",\"ZA\",\"GS\",\"KR\",\"SS\",\"ES\",\"LK\",\"SD\",\"SR\",\"SJ\",\"SZ\",\"SE\",\"CH\",\"SY\",\"TW\",\"TJ\",\"TZ\",\"TH\",\"TL\",\"TG\",\"TK\",\"TO\",\"TT\",\"TN\",\"TR\",\"TM\",\"TC\",\"TV\",\"UG\",\"UA\",\"AE\",\"GB\",\"US\",\"UM\",\"VI\",\"UY\",\"UZ\",\"VU\",\"VA\",\"VE\",\"VN\",\"WF\",\"EH\",\"WS\",\"YE\",\"ZM\",\"ZW\"],\"default_value\":\"AF\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-flag\"},{\"field_key\":\"date\",\"general_setting\":{\"label\":\"Date of Birth\",\"description\":\"\",\"field_name\":\"date_box_1623051693\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"date_format\":\"Y-m-d\",\"enable_min_max\":\"false\",\"min_date\":\"\",\"max_date\":\"\",\"set_current_date\":\"\",\"enable_date_range\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-calendar\"}],[{\"field_key\":\"last_name\",\"general_setting\":{\"label\":\"Last Name\",\"description\":\"\",\"field_name\":\"last_name\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-last-name\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"City\",\"description\":\"\",\"field_name\":\"input_box_1623050696\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"State\",\"description\":\"\",\"field_name\":\"input_box_1623050759\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Zip Code\",\"description\":\"\",\"field_name\":\"input_box_1623050879\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"radio\",\"general_setting\":{\"label\":\"Gender\",\"description\":\"\",\"field_name\":\"radio_1623051748\",\"options\":[\"Male\",\"Female\",\"Other\"],\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\",\"options\":\"Male,Female,Other\"},\"icon\":\"ur-icon ur-icon-radio\"}]],[[]],[[{\"field_key\":\"user_email\",\"general_setting\":{\"label\":\"Student email address\",\"description\":\"\",\"field_name\":\"user_email\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-email\"},{\"field_key\":\"user_pass\",\"general_setting\":{\"label\":\"Password\",\"description\":\"\",\"field_name\":\"user_pass\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"field_visibility\":\"both\"},\"icon\":\"ur-icon ur-icon-password\"}],[{\"field_key\":\"user_confirm_email\",\"general_setting\":{\"label\":\"Confirm student email address\",\"description\":\"\",\"field_name\":\"user_confirm_email\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"field_visibility\":\"both\"},\"icon\":\"ur-icon ur-icon-email-confirm\"},{\"field_key\":\"user_confirm_password\",\"general_setting\":{\"label\":\"Confirm Password\",\"description\":\"\",\"field_name\":\"user_confirm_password\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"field_visibility\":\"both\"},\"icon\":\"ur-icon ur-icon-password-confirm\"}]],[[]],[[{\"field_key\":\"select\",\"general_setting\":{\"label\":\"Course\",\"description\":\"\",\"field_name\":\"select_1623053939\",\"options\":[\"SLC\",\"Plus 2\",\"Bachelor\",\"Master\",\"Diploma\"],\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\",\"options\":\"SLC,Plus 2,Bachelor,Master,Diploma\"},\"icon\":\"ur-icon ur-icon-drop-down\"},{\"field_key\":\"select\",\"general_setting\":{\"label\":\"Course\",\"description\":\"\",\"field_name\":\"select_1623075235990\",\"options\":[\"SLC\",\"Plus 2\",\"Bachelor\",\"Master\",\"Diploma\"],\"default_value\":\"Plus 2\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"yes\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\",\"options\":\"SLC,Plus 2,Bachelor,Master,Diploma\"},\"icon\":\"ur-icon ur-icon-drop-down\"},{\"field_key\":\"select\",\"general_setting\":{\"label\":\"Course\",\"description\":\"\",\"field_name\":\"select_1623075252220\",\"options\":[\"SLC\",\"Plus 2\",\"Bachelor\",\"Master\",\"Diploma\"],\"default_value\":\"Bachelor\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"yes\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\",\"options\":\"SLC,Plus 2,Bachelor,Master,Diploma\"},\"icon\":\"ur-icon ur-icon-drop-down\"}],[{\"field_key\":\"text\",\"general_setting\":{\"label\":\"School/University\",\"description\":\"\",\"field_name\":\"input_box_1623075201\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"School/University\",\"description\":\"\",\"field_name\":\"input_box_1623075238301\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"yes\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"School/University\",\"description\":\"\",\"field_name\":\"input_box_1623075254142\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"yes\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"}],[{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Grade/Percentage\",\"description\":\"\",\"field_name\":\"input_box_1623054140\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Grade/Percentage\",\"description\":\"\",\"field_name\":\"input_box_1623075240823\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"yes\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Grade/Percentage\",\"description\":\"\",\"field_name\":\"input_box_1623075256147\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"yes\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"}]],[[]],[[{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Mother\'s Name\",\"description\":\"\",\"field_name\":\"input_box_1623052350\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Father\'s Name\",\"description\":\"\",\"field_name\":\"input_box_1623053158710\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"textarea\",\"general_setting\":{\"label\":\"Address\",\"description\":\"\",\"field_name\":\"textarea_1623052454\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-textarea\"}],[{\"field_key\":\"email\",\"general_setting\":{\"label\":\"Mother\'s email address\",\"description\":\"\",\"field_name\":\"email_1623052525\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-email-secondary\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Mother\'s Profession\",\"description\":\"\",\"field_name\":\"input_box_1623052381811\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"email\",\"general_setting\":{\"label\":\"Father\'s email address\",\"description\":\"\",\"field_name\":\"email_1623052798021\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-email-secondary\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Father\'s Profession\",\"description\":\"\",\"field_name\":\"input_box_1623053192355\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-input-field\"}]],[[{\"field_key\":\"checkbox\",\"general_setting\":{\"label\":\"Hobbies\",\"description\":\"\",\"field_name\":\"check_box_1623078065\",\"options\":[\"Drawing\",\"Singing\",\"Dancing\",\"Sketching\",\"Other\"],\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"choice_limit\":\"\",\"select_all\":\"no\",\"enable_prepopulate\":\"false\",\"parameter_name\":\"\",\"enable_conditional_logic\":\"\",\"cl_map\":\"{\\\"action\\\":\\\"show\\\",\\\"logic_map\\\":{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"OR\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"group\\\",\\\"logic_gate\\\":\\\"\\\",\\\"conditions\\\":[{\\\"type\\\":\\\"field\\\",\\\"triggerer_id\\\":\\\"\\\",\\\"operator\\\":\\\"is\\\",\\\"value\\\":\\\"\\\"}]}]}}\",\"field_visibility\":\"both\",\"read_only\":\"none\",\"choices\":\"Drawing,Singing,Dancing,Sketching,Other\"},\"icon\":\"ur-icon ur-icon-input-checkbox\"},{\"field_key\":\"privacy_policy\",\"general_setting\":{\"label\":\"Declaration\",\"description\":\"I hereby declare that the above information is true and correct.\",\"field_name\":\"privacy_policy_1623078743\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"read_only\":\"none\"},\"icon\":\"ur-icon ur-icon-doc\"}]]]', 'Student Regi', '', 'trash', 'closed', 'closed', '', 'student-registration__trashed', '', '', '2023-04-12 01:42:23', '2023-04-12 01:42:23', '', 0, 'http://localhost/jcubhomefinder/?post_type=user_registration&#038;p=57', 0, 'user_registration', '', 0),
(58, 1, '2023-04-12 01:39:21', '2023-04-12 01:39:21', '[[[]],[[{\"field_key\":\"first_name\",\"general_setting\":{\"label\":\"First Name\",\"description\":\"\",\"field_name\":\"first_name\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-first-name\"},{\"field_key\":\"textarea\",\"general_setting\":{\"label\":\"Mailing Address\",\"description\":\"\",\"field_name\":\"textarea_1623050614\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-textarea\"},{\"field_key\":\"country\",\"general_setting\":{\"label\":\"Country\",\"description\":\"\",\"field_name\":\"country_1623050729\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"selected_countries\":[\"AF\",\"AX\",\"AL\",\"DZ\",\"AS\",\"AD\",\"AO\",\"AI\",\"AQ\",\"AG\",\"AR\",\"AM\",\"AW\",\"AU\",\"AT\",\"AZ\",\"BS\",\"BH\",\"BD\",\"BB\",\"BY\",\"BE\",\"PW\",\"BZ\",\"BJ\",\"BM\",\"BT\",\"BO\",\"BQ\",\"BA\",\"BW\",\"BV\",\"BR\",\"IO\",\"VG\",\"BN\",\"BG\",\"BF\",\"BI\",\"KH\",\"CM\",\"CA\",\"CV\",\"KY\",\"CF\",\"TD\",\"CL\",\"CN\",\"CX\",\"CC\",\"CO\",\"KM\",\"CG\",\"CD\",\"CK\",\"CR\",\"HR\",\"CU\",\"CW\",\"CY\",\"CZ\",\"DK\",\"DJ\",\"DM\",\"DO\",\"EC\",\"EG\",\"SV\",\"GQ\",\"ER\",\"EE\",\"ET\",\"FK\",\"FO\",\"FJ\",\"FI\",\"FR\",\"GF\",\"PF\",\"TF\",\"GA\",\"GM\",\"GE\",\"DE\",\"GH\",\"GI\",\"GR\",\"GL\",\"GD\",\"GP\",\"GU\",\"GT\",\"GG\",\"GN\",\"GW\",\"GY\",\"HT\",\"HM\",\"HN\",\"HK\",\"HU\",\"IS\",\"IN\",\"ID\",\"IR\",\"IQ\",\"IE\",\"IM\",\"IL\",\"IT\",\"CI\",\"JM\",\"JP\",\"JE\",\"JO\",\"KZ\",\"KE\",\"KI\",\"KW\",\"KG\",\"LA\",\"LV\",\"LB\",\"LS\",\"LR\",\"LY\",\"LI\",\"LT\",\"LU\",\"MO\",\"MK\",\"MG\",\"MW\",\"MY\",\"MV\",\"ML\",\"MT\",\"MH\",\"MQ\",\"MR\",\"MU\",\"YT\",\"MX\",\"FM\",\"MD\",\"MC\",\"MN\",\"ME\",\"MS\",\"MA\",\"MZ\",\"MM\",\"NA\",\"NR\",\"NP\",\"NL\",\"NC\",\"NZ\",\"NI\",\"NE\",\"NG\",\"NU\",\"NF\",\"MP\",\"KP\",\"NO\",\"OM\",\"PK\",\"PS\",\"PA\",\"PG\",\"PY\",\"PE\",\"PH\",\"PN\",\"PL\",\"PT\",\"PR\",\"QA\",\"RE\",\"RO\",\"RU\",\"RW\",\"BL\",\"SH\",\"KN\",\"LC\",\"MF\",\"SX\",\"PM\",\"VC\",\"SM\",\"ST\",\"SA\",\"SN\",\"RS\",\"SC\",\"SL\",\"SG\",\"SK\",\"SI\",\"SB\",\"SO\",\"ZA\",\"GS\",\"KR\",\"SS\",\"ES\",\"LK\",\"SD\",\"SR\",\"SJ\",\"SZ\",\"SE\",\"CH\",\"SY\",\"TW\",\"TJ\",\"TZ\",\"TH\",\"TL\",\"TG\",\"TK\",\"TO\",\"TT\",\"TN\",\"TR\",\"TM\",\"TC\",\"TV\",\"UG\",\"UA\",\"AE\",\"GB\",\"US\",\"UM\",\"VI\",\"UY\",\"UZ\",\"VU\",\"VA\",\"VE\",\"VN\",\"WF\",\"EH\",\"WS\",\"YE\",\"ZM\",\"ZW\"],\"default_value\":\"AF\"},\"icon\":\"ur-icon ur-icon-flag\"},{\"field_key\":\"date\",\"general_setting\":{\"label\":\"Date of Birth\",\"description\":\"\",\"field_name\":\"date_box_1623051693\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"date_format\":\"Y-m-d\",\"enable_min_max\":\"false\",\"min_date\":\"\",\"max_date\":\"\",\"set_current_date\":\"\",\"enable_date_range\":\"\",\"date_localization\":\"en\"},\"icon\":\"ur-icon ur-icon-calendar\"}],[{\"field_key\":\"last_name\",\"general_setting\":{\"label\":\"Last Name\",\"description\":\"\",\"field_name\":\"last_name\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-last-name\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"City\",\"description\":\"\",\"field_name\":\"input_box_1623050696\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"State\",\"description\":\"\",\"field_name\":\"input_box_1623050759\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Zip Code\",\"description\":\"\",\"field_name\":\"input_box_1623050879\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"radio\",\"general_setting\":{\"label\":\"Gender\",\"description\":\"\",\"field_name\":\"radio_1623051748\",\"options\":[\"Male\",\"Female\",\"Other\"],\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"options\":\"Male,Female,Other\"},\"icon\":\"ur-icon ur-icon-radio\"}]],[[]],[[{\"field_key\":\"user_email\",\"general_setting\":{\"label\":\"Student email address\",\"description\":\"\",\"field_name\":\"user_email\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-email\"},{\"field_key\":\"user_pass\",\"general_setting\":{\"label\":\"Password\",\"description\":\"\",\"field_name\":\"user_pass\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-password\"}],[{\"field_key\":\"user_confirm_email\",\"general_setting\":{\"label\":\"Confirm student email address\",\"description\":\"\",\"field_name\":\"user_confirm_email\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-email-confirm\"},{\"field_key\":\"user_confirm_password\",\"general_setting\":{\"label\":\"Confirm Password\",\"description\":\"\",\"field_name\":\"user_confirm_password\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-password-confirm\"}]],[[]],[[{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Father\'s Name\",\"description\":\"\",\"field_name\":\"input_box_1623053158710\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"text\",\"general_setting\":{\"label\":\"Mother\'s Name\",\"description\":\"\",\"field_name\":\"input_box_1623052350\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"size\":\"20\",\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-input-field\"},{\"field_key\":\"textarea\",\"general_setting\":{\"label\":\"Address\",\"description\":\"\",\"field_name\":\"textarea_1623052454\",\"placeholder\":\"\",\"required\":\"no\",\"hide_label\":\"no\"},\"advance_setting\":{\"default_value\":\"\",\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-textarea\"}]]]', 'Student Registration', '', 'publish', 'closed', 'closed', '', 'student-registration-2', '', '', '2023-04-12 01:39:21', '2023-04-12 01:39:21', '', 0, 'http://localhost/jcubhomefinder/?post_type=user_registration&#038;p=58', 0, 'user_registration', '', 0),
(59, 1, '2023-04-12 01:40:22', '2023-04-12 01:40:22', '<!-- wp:shortcode -->\n[user_registration_form id=\"58\"]\n<!-- /wp:shortcode -->', 'Student', '', 'inherit', 'closed', 'closed', '', '52-autosave-v1', '', '', '2023-04-12 01:40:22', '2023-04-12 01:40:22', '', 52, 'http://localhost/jcubhomefinder/?p=59', 0, 'revision', '', 0),
(60, 1, '2023-04-12 01:40:37', '2023-04-12 01:40:37', '<!-- wp:shortcode -->\n[user_registration_form id=\"58\"]\n<!-- /wp:shortcode -->', 'Student', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2023-04-12 01:40:37', '2023-04-12 01:40:37', '', 52, 'http://localhost/jcubhomefinder/?p=60', 0, 'revision', '', 0),
(61, 1, '2023-04-12 01:41:06', '2023-04-12 01:41:06', '{\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:41:06\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:41:06\"\n    },\n    \"nav_menu_item[-6061647597834375000]\": {\n        \"value\": {\n            \"object_id\": 52,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"post_type\",\n            \"title\": \"Student\",\n            \"url\": \"http://localhost/jcubhomefinder/student/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Student\",\n            \"nav_menu_term_id\": 3,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:41:06\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'a5c092eb-3beb-4719-8683-a54169bb40bb', '', '', '2023-04-12 01:41:06', '2023-04-12 01:41:06', '', 0, 'http://localhost/jcubhomefinder/2023/04/12/a5c092eb-3beb-4719-8683-a54169bb40bb/', 0, 'customize_changeset', '', 0),
(62, 1, '2023-04-12 02:00:40', '2023-04-12 01:41:06', ' ', '', '', 'publish', 'closed', 'closed', '', '62', '', '', '2023-04-12 02:00:40', '2023-04-12 02:00:40', '', 0, 'http://localhost/jcubhomefinder/2023/04/12/62/', 2, 'nav_menu_item', '', 0),
(63, 1, '2023-04-12 01:41:14', '2023-04-12 01:41:14', '[user_registration_form id=\"54\"]', 'Registration', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2023-04-12 01:41:14', '2023-04-12 01:41:14', '', 55, 'http://localhost/jcubhomefinder/?p=63', 0, 'revision', '', 0),
(64, 1, '2023-04-12 01:41:28', '2023-04-12 01:41:28', '{\n    \"nav_menu_item[50]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 26,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"Front Page\",\n            \"url\": \"http://localhost/jcubhomefinder/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 1,\n            \"status\": \"publish\",\n            \"original_title\": \"Home\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:41:28\"\n    },\n    \"nav_menu_item[62]\": {\n        \"value\": {\n            \"object_id\": 52,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"post_type\",\n            \"title\": \"Student\",\n            \"url\": \"http://localhost/jcubhomefinder/student/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Student\",\n            \"nav_menu_term_id\": 3,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:41:28\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '88679e8a-4180-4d0e-9ce0-34599c700d39', '', '', '2023-04-12 01:41:28', '2023-04-12 01:41:28', '', 0, 'http://localhost/jcubhomefinder/2023/04/12/88679e8a-4180-4d0e-9ce0-34599c700d39/', 0, 'customize_changeset', '', 0),
(65, 1, '2023-04-12 01:45:27', '2023-04-12 01:45:27', '{\n    \"real-home::real_home_header_builder_controller_section\": {\n        \"value\": \"%7B%22desktop%22:%7B%22top%22:%7B%22col-0%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-1%22:%5B%7B%22id%22:%22primary_menu%22%7D%5D,%22col-2%22:%5B%7B%22id%22:%22account%22%7D%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D,%22mobile%22:%7B%22top%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-2%22:%5B%7B%22id%22:%22toggle_menu%22%7D%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D%7D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:45:27\"\n    },\n    \"real-home::real_home_footer_builder_controller_section\": {\n        \"value\": \"%7B%22desktop%22:%7B%22top%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%7B%22id%22:%22footer_copyright%22%7D%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%7B%22id%22:%22footer_social%22%7D%5D%7D%7D%7D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:44:29\"\n    },\n    \"real-home::real_home_header_account_login_text\": {\n        \"value\": \"Manage Account\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:45:27\"\n    },\n    \"real-home::real_home_header_account_url_target\": {\n        \"value\": {\n            \"desktop\": \"true\"\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:45:27\"\n    },\n    \"real-home::real_home_header_account_border\": {\n        \"value\": {\n            \"width\": {\n                \"side_1\": \"0px\",\n                \"side_2\": \"0px\",\n                \"side_3\": \"0px\",\n                \"side_4\": \"0px\",\n                \"linked\": \"on\"\n            },\n            \"colors\": []\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 01:45:27\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b851323f-473e-4737-b650-08e2252420ca', '', '', '2023-04-12 01:45:27', '2023-04-12 01:45:27', '', 0, 'http://localhost/jcubhomefinder/?p=65', 0, 'customize_changeset', '', 0),
(66, 1, '2023-04-12 01:46:40', '2023-04-12 01:46:40', '[[[{\"field_key\":\"user_login\",\"general_setting\":{\"label\":\"Username\",\"description\":\"\",\"field_name\":\"user_login\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\",\"username_length\":\"\",\"username_character\":\"yes\"},\"icon\":\"ur-icon ur-icon-user\"},{\"field_key\":\"user_pass\",\"general_setting\":{\"label\":\"User Password\",\"description\":\"\",\"field_name\":\"user_pass\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-password\"}],[{\"field_key\":\"user_email\",\"general_setting\":{\"label\":\"User Email\",\"description\":\"\",\"field_name\":\"user_email\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-email\"},{\"field_key\":\"user_confirm_password\",\"general_setting\":{\"label\":\"Confirm Password\",\"description\":\"\",\"field_name\":\"user_confirm_password\",\"placeholder\":\"\",\"required\":\"yes\",\"hide_label\":\"no\"},\"advance_setting\":{\"custom_class\":\"\"},\"icon\":\"ur-icon ur-icon-password-confirm\"}]]]', 'Login', '', 'trash', 'closed', 'closed', '', 'login__trashed', '', '', '2023-04-12 01:49:19', '2023-04-12 01:49:19', '', 0, 'http://localhost/jcubhomefinder/?post_type=user_registration&#038;p=66', 0, 'user_registration', '', 0),
(67, 1, '2023-04-12 01:47:05', '2023-04-12 01:47:05', '[user_registration_form id=\"66\"]', 'My Account', '', 'inherit', 'closed', 'closed', '', '56-autosave-v1', '', '', '2023-04-12 01:47:05', '2023-04-12 01:47:05', '', 56, 'http://localhost/jcubhomefinder/?p=67', 0, 'revision', '', 0),
(68, 1, '2023-04-12 01:47:23', '2023-04-12 01:47:23', '[user_registration_form id=\"66\"]', 'My Account', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2023-04-12 01:47:23', '2023-04-12 01:47:23', '', 56, 'http://localhost/jcubhomefinder/?p=68', 0, 'revision', '', 0),
(69, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_register]', 'Register', '', 'publish', 'closed', 'closed', '', 'register', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/register/', 0, 'page', '', 0),
(70, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_login]', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/login/', 0, 'page', '', 0),
(71, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_account]', 'Account', '', 'publish', 'closed', 'closed', '', 'account', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/account/', 0, 'page', '', 0),
(72, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_forgot]', 'Forgot Password?', '', 'publish', 'closed', 'closed', '', 'forgot', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/forgot/', 0, 'page', '', 0),
(73, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_reset]', 'Reset Password', '', 'publish', 'closed', 'closed', '', 'reset', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/reset/', 0, 'page', '', 0),
(74, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_change]', 'Change Password', '', 'publish', 'closed', 'closed', '', 'change', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/change/', 0, 'page', '', 0),
(75, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_profile]', 'Profile', '', 'publish', 'closed', 'closed', '', 'profile', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/profile/', 0, 'page', '', 0),
(76, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_users]', 'Users', '', 'publish', 'closed', 'closed', '', 'users', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/users/', 0, 'page', '', 0),
(77, 1, '2023-04-12 01:50:59', '2023-04-12 01:50:59', '[uwp_users_item]', 'Users List Item', '', 'publish', 'closed', 'closed', '', 'user-list-item', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 0, 'http://localhost/jcubhomefinder/user-list-item/', 0, 'page', '', 0),
(78, 0, '2023-04-12 01:51:10', '2023-04-12 01:51:10', '[uwp_users_item]', 'Users List Item', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2023-04-12 01:51:10', '2023-04-12 01:51:10', '', 77, 'http://localhost/jcubhomefinder/?p=78', 0, 'revision', '', 0),
(86, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_login]', 'Login', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 70, 'http://localhost/jcubhomefinder/?p=86', 0, 'revision', '', 0),
(87, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_register]', 'Register', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 69, 'http://localhost/jcubhomefinder/?p=87', 0, 'revision', '', 0),
(88, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_change]', 'Change Password', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 74, 'http://localhost/jcubhomefinder/?p=88', 0, 'revision', '', 0),
(89, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_forgot]', 'Forgot Password?', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 72, 'http://localhost/jcubhomefinder/?p=89', 0, 'revision', '', 0),
(90, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_reset]', 'Reset Password', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 73, 'http://localhost/jcubhomefinder/?p=90', 0, 'revision', '', 0),
(91, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_profile]', 'Profile', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 75, 'http://localhost/jcubhomefinder/?p=91', 0, 'revision', '', 0),
(92, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_account]', 'Account', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 71, 'http://localhost/jcubhomefinder/?p=92', 0, 'revision', '', 0),
(93, 1, '2023-04-12 01:51:26', '2023-04-12 01:51:26', '[uwp_users]', 'Users', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2023-04-12 01:51:26', '2023-04-12 01:51:26', '', 76, 'http://localhost/jcubhomefinder/?p=93', 0, 'revision', '', 0),
(95, 1, '2023-04-13 00:43:33', '2023-04-12 01:58:55', ' ', '', '', 'publish', 'closed', 'closed', '', '95', '', '', '2023-04-13 00:43:33', '2023-04-13 00:43:33', '', 0, 'http://localhost/jcubhomefinder/?p=95', 6, 'nav_menu_item', '', 0),
(96, 1, '2023-04-13 00:43:33', '2023-04-12 01:58:55', ' ', '', '', 'publish', 'closed', 'closed', '', '96', '', '', '2023-04-13 00:43:33', '2023-04-13 00:43:33', '', 0, 'http://localhost/jcubhomefinder/?p=96', 7, 'nav_menu_item', '', 0),
(97, 1, '2023-04-13 00:43:33', '2023-04-12 01:58:55', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2023-04-13 00:43:33', '2023-04-13 00:43:33', '', 0, 'http://localhost/jcubhomefinder/?p=97', 8, 'nav_menu_item', '', 0),
(98, 1, '2023-04-12 01:59:49', '2023-04-12 01:59:49', '', 'AP', '', 'publish', 'closed', 'closed', '', 'ap', '', '', '2023-04-12 01:59:49', '2023-04-12 01:59:49', '', 0, 'http://localhost/jcubhomefinder/?page_id=98', 0, 'page', '', 0),
(99, 1, '2023-04-12 01:59:49', '2023-04-12 01:59:49', '', 'AP', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2023-04-12 01:59:49', '2023-04-12 01:59:49', '', 98, 'http://localhost/jcubhomefinder/?p=99', 0, 'revision', '', 0),
(100, 1, '2023-04-12 02:00:01', '2023-04-12 02:00:01', '<!-- wp:paragraph -->\n<p>Phone No: 0000000000 (9 am to 4 pm)</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Email Address: xyz@gmail.com</p>\n<!-- /wp:paragraph -->', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2023-04-12 14:04:05', '2023-04-12 14:04:05', '', 0, 'http://localhost/jcubhomefinder/?page_id=100', 0, 'page', '', 0),
(101, 1, '2023-04-12 02:00:01', '2023-04-12 02:00:01', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '100-revision-v1', '', '', '2023-04-12 02:00:01', '2023-04-12 02:00:01', '', 100, 'http://localhost/jcubhomefinder/?p=101', 0, 'revision', '', 0),
(102, 1, '2023-04-12 02:00:40', '2023-04-12 02:00:40', ' ', '', '', 'publish', 'closed', 'closed', '', '102', '', '', '2023-04-12 02:00:40', '2023-04-12 02:00:40', '', 0, 'http://localhost/jcubhomefinder/?p=102', 3, 'nav_menu_item', '', 0),
(103, 1, '2023-04-13 00:43:33', '2023-04-12 02:00:41', ' ', '', '', 'publish', 'closed', 'closed', '', '103', '', '', '2023-04-13 00:43:33', '2023-04-13 00:43:33', '', 0, 'http://localhost/jcubhomefinder/?p=103', 5, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(104, 1, '2023-04-12 02:02:00', '2023-04-12 02:02:00', '{\n    \"real-home::real_home_header_builder_controller_section\": {\n        \"value\": \"%7B%22desktop%22:%7B%22top%22:%7B%22col-0%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-1%22:%5B%7B%22id%22:%22primary_menu%22%7D%5D,%22col-2%22:%5B%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D,%22mobile%22:%7B%22top%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-2%22:%5B%7B%22id%22:%22toggle_menu%22%7D%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D%7D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 02:02:00\"\n    },\n    \"real-home::real_home_footer_builder_controller_section\": {\n        \"value\": \"%7B%22desktop%22:%7B%22top%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%7B%22id%22:%22footer_copyright%22%7D%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%7B%22id%22:%22footer_social%22%7D%5D%7D%7D%7D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 02:02:00\"\n    },\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 02:02:00\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 02:02:00\"\n    },\n    \"real-home::nav_menu_locations[mobile-menu]\": {\n        \"value\": 3,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 02:02:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '19fa70cd-f69d-47fe-832e-2057918aee0f', '', '', '2023-04-12 02:02:00', '2023-04-12 02:02:00', '', 0, 'http://localhost/jcubhomefinder/2023/04/12/19fa70cd-f69d-47fe-832e-2057918aee0f/', 0, 'customize_changeset', '', 0),
(105, 1, '2023-04-12 02:03:51', '2023-04-12 02:03:51', '{\n    \"real-home::real_home_header_builder_controller_section\": {\n        \"value\": \"%7B%22desktop%22:%7B%22top%22:%7B%22col-0%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-1%22:%5B%7B%22id%22:%22primary_menu%22%7D%5D,%22col-2%22:%5B%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D,%22mobile%22:%7B%22top%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%7B%22id%22:%22title_tagline%22%7D%5D,%22col-2%22:%5B%7B%22id%22:%22toggle_menu%22%7D%5D%7D,%22main%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D,%22bottom%22:%7B%22col-0%22:%5B%5D,%22col-1%22:%5B%5D,%22col-2%22:%5B%5D%7D%7D%7D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-12 02:03:51\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'fd6b0c75-1b42-4860-ad33-9d1e6e0fec5a', '', '', '2023-04-12 02:03:51', '2023-04-12 02:03:51', '', 0, 'http://localhost/jcubhomefinder/?p=105', 0, 'customize_changeset', '', 0),
(106, 1, '2023-04-12 13:48:26', '2023-04-12 13:48:26', '<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":35,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1-1024x461.jpg\" alt=\"\" class=\"wp-image-35\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":36,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage2.jpeg\" alt=\"\" class=\"wp-image-36\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:image {\"id\":35,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomepage_sampleimage1-1024x461.jpg\" alt=\"\" class=\"wp-image-35\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:strongtestimonials/view {\"id\":1} /-->', 'Home', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2023-04-12 13:48:26', '2023-04-12 13:48:26', '', 26, 'http://localhost/jcubhomefinder/?p=106', 0, 'revision', '', 0),
(107, 1, '2023-04-12 14:03:55', '2023-04-12 14:03:55', '<!-- wp:paragraph -->\n<p>Phone No: 0000000000 (9 am to 4 pm)</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Email Address: xyz@gmail.com</p>\n<!-- /wp:paragraph -->', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '100-autosave-v1', '', '', '2023-04-12 14:03:55', '2023-04-12 14:03:55', '', 100, 'http://localhost/jcubhomefinder/?p=107', 0, 'revision', '', 0),
(108, 1, '2023-04-12 14:04:05', '2023-04-12 14:04:05', '<!-- wp:paragraph -->\n<p>Phone No: 0000000000 (9 am to 4 pm)</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Email Address: xyz@gmail.com</p>\n<!-- /wp:paragraph -->', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '100-revision-v1', '', '', '2023-04-12 14:04:05', '2023-04-12 14:04:05', '', 100, 'http://localhost/jcubhomefinder/?p=108', 0, 'revision', '', 0),
(109, 1, '2023-04-13 00:41:02', '2023-04-13 00:41:02', '<!-- wp:list {\"ordered\":true} -->\n<ol><!-- wp:list-item -->\n<li><strong>How do I make a payment?</strong><br><em>You cannot make a direct payment through the website.</em><br><em>You might have to contact the AP and ask the preferred mode of payment in order to initiate one.</em> </li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Where do I see the rental fees?</strong><br><em>Rent mentioned on the website is on per week basis. You can view it when you search for the property.</em></li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>How to register as a student?</strong><br>Go to the register page of student. Click here to register.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>How to register as an Accommodation provider (AP)?</strong><br>Go to the register page of AP. Click here</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Will there be any fee associated with the registration?</strong><br><em>There is no cost associated with registration. Whether a student or an AP it is unpaid.</em></li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>How do I contact the AP?</strong><br><em>You may contact the AP using the details mentioned on their respective property.</em><br><em>Make sure you have checked their contact availability before reaching out.</em></li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Can I negotiate on the rental fee?</strong><br><em>Be rest assured with the rental rate as our team has made sure to negotiate and get you the best deal.</em><br><em>You can, however, try your luck if you like.</em></li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'FAQ', '', 'publish', 'closed', 'closed', '', 'faq', '', '', '2023-04-13 00:41:02', '2023-04-13 00:41:02', '', 0, 'http://localhost/jcubhomefinder/?page_id=109', 0, 'page', '', 0),
(110, 1, '2023-04-13 00:41:02', '2023-04-13 00:41:02', '<!-- wp:list {\"ordered\":true} -->\n<ol><!-- wp:list-item -->\n<li><strong>How do I make a payment?</strong><br><em>You cannot make a direct payment through the website.</em><br><em>You might have to contact the AP and ask the preferred mode of payment in order to initiate one.</em> </li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Where do I see the rental fees?</strong><br><em>Rent mentioned on the website is on per week basis. You can view it when you search for the property.</em></li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>How to register as a student?</strong><br>Go to the register page of student. Click here to register.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>How to register as an Accommodation provider (AP)?</strong><br>Go to the register page of AP. Click here</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Will there be any fee associated with the registration?</strong><br><em>There is no cost associated with registration. Whether a student or an AP it is unpaid.</em></li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>How do I contact the AP?</strong><br><em>You may contact the AP using the details mentioned on their respective property.</em><br><em>Make sure you have checked their contact availability before reaching out.</em></li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Can I negotiate on the rental fee?</strong><br><em>Be rest assured with the rental rate as our team has made sure to negotiate and get you the best deal.</em><br><em>You can, however, try your luck if you like.</em></li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'FAQ', '', 'inherit', 'closed', 'closed', '', '109-revision-v1', '', '', '2023-04-13 00:41:02', '2023-04-13 00:41:02', '', 109, 'http://localhost/jcubhomefinder/?p=110', 0, 'revision', '', 0),
(111, 1, '2023-04-13 00:43:33', '2023-04-13 00:43:33', '{\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    },\n    \"nav_menu_item[103]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 100,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"Page\",\n            \"url\": \"http://localhost/jcubhomefinder/contact-us/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 5,\n            \"status\": \"publish\",\n            \"original_title\": \"Contact Us\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    },\n    \"nav_menu_item[95]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 56,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"Page\",\n            \"url\": \"http://localhost/jcubhomefinder/my-account/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 6,\n            \"status\": \"publish\",\n            \"original_title\": \"My Account\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    },\n    \"nav_menu_item[96]\": {\n        \"value\": {\n            \"menu_item_parent\": 95,\n            \"object_id\": 70,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"UWP Login Page\",\n            \"url\": \"http://localhost/jcubhomefinder/login/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 7,\n            \"status\": \"publish\",\n            \"original_title\": \"Login\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    },\n    \"nav_menu_item[97]\": {\n        \"value\": {\n            \"menu_item_parent\": 95,\n            \"object_id\": 69,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"UWP Register Page\",\n            \"url\": \"http://localhost/jcubhomefinder/register/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 8,\n            \"status\": \"publish\",\n            \"original_title\": \"Register\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    },\n    \"nav_menu_item[-5137371662953055000]\": {\n        \"value\": {\n            \"object_id\": 109,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 4,\n            \"type\": \"post_type\",\n            \"title\": \"FAQ\",\n            \"url\": \"http://localhost/jcubhomefinder/faq/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"FAQ\",\n            \"nav_menu_term_id\": 3,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 00:43:33\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '28ad23da-d5f2-4346-805c-0e4d6bc31a9c', '', '', '2023-04-13 00:43:33', '2023-04-13 00:43:33', '', 0, 'http://localhost/jcubhomefinder/2023/04/13/28ad23da-d5f2-4346-805c-0e4d6bc31a9c/', 0, 'customize_changeset', '', 0),
(112, 1, '2023-04-13 00:43:33', '2023-04-13 00:43:33', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2023-04-13 00:43:33', '2023-04-13 00:43:33', '', 0, 'http://localhost/jcubhomefinder/2023/04/13/112/', 4, 'nav_menu_item', '', 0),
(113, 1, '2023-04-13 01:22:30', '2023-04-13 01:22:30', '', 'jcubhomefinder-logo', '', 'inherit', 'open', 'closed', '', 'jcubhomefinder-logo', '', '', '2023-04-13 01:22:30', '2023-04-13 01:22:30', '', 0, 'http://localhost/jcubhomefinder/wp-content/uploads/2023/04/jcubhomefinder-logo.png', 0, 'attachment', 'image/png', 0),
(114, 1, '2023-04-13 01:23:38', '2023-04-13 01:23:38', '{\n    \"real-home::custom_logo\": {\n        \"value\": 113,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 01:23:38\"\n    },\n    \"real-home::real_home_social_icons\": {\n        \"value\": \"%5B%7B%22network%22:%22facebook%22,%22icon%22:%22%22,%22link%22:%22#%22%7D,%7B%22network%22:%22twitter%22,%22icon%22:%22%22,%22link%22:%22#%22%7D%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 01:23:38\"\n    },\n    \"real-home::real_home_front_page_clients_logo_lists\": {\n        \"value\": \"%5B%5D\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-13 01:23:38\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'cc5d83eb-ecc4-43fc-b2ef-e477cdf5b2d9', '', '', '2023-04-13 01:23:38', '2023-04-13 01:23:38', '', 0, 'http://localhost/jcubhomefinder/2023/04/13/cc5d83eb-ecc4-43fc-b2ef-e477cdf5b2d9/', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_strong_views`
--

CREATE TABLE `wp_strong_views` (
  `id` mediumint(9) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_strong_views`
--

INSERT INTO `wp_strong_views` (`id`, `name`, `value`) VALUES
(1, 'Testimonial Slider', 'a:41:{s:10:\"background\";a:5:{s:5:\"color\";s:0:\"\";s:4:\"type\";s:0:\"\";s:6:\"preset\";s:0:\"\";s:9:\"gradient1\";s:0:\"\";s:9:\"gradient2\";s:0:\"\";}s:8:\"category\";s:3:\"all\";s:5:\"class\";s:0:\"\";s:14:\"client_section\";N;s:12:\"column_count\";s:1:\"3\";s:7:\"content\";s:9:\"truncated\";s:5:\"count\";i:-1;s:12:\"divi_builder\";i:0;s:14:\"excerpt_length\";i:55;s:10:\"font-color\";a:2:{s:4:\"type\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:9:\"form_ajax\";i:0;s:7:\"form_id\";s:1:\"1\";s:8:\"gravatar\";s:2:\"no\";s:12:\"html_content\";i:0;s:2:\"id\";i:0;s:6:\"layout\";s:7:\"masonry\";s:14:\"less_post_text\";s:9:\"Show less\";s:8:\"lightbox\";i:0;s:14:\"lightbox_class\";s:0:\"\";s:4:\"mode\";s:7:\"display\";s:14:\"more_full_post\";s:1:\"0\";s:14:\"more_page_hook\";s:18:\"wpmtst_view_footer\";s:14:\"more_page_text\";s:22:\"Read more testimonials\";s:9:\"more_post\";i:1;s:18:\"more_post_ellipsis\";s:1:\"1\";s:18:\"more_post_in_place\";s:1:\"0\";s:14:\"more_post_text\";s:9:\"Read more\";s:5:\"order\";s:6:\"random\";s:10:\"pagination\";i:0;s:19:\"pagination_settings\";a:11:{s:4:\"type\";s:6:\"simple\";s:3:\"nav\";s:5:\"after\";s:8:\"show_all\";b:0;s:9:\"prev_next\";b:1;s:9:\"prev_text\";s:16:\"&laquo; Previous\";s:9:\"next_text\";s:12:\"Next &raquo;\";s:18:\"before_page_number\";s:0:\"\";s:17:\"after_page_number\";s:0:\"\";s:8:\"end_size\";i:1;s:8:\"mid_size\";i:2;s:8:\"per_page\";i:5;}s:18:\"slideshow_settings\";a:18:{s:12:\"adapt_height\";i:1;s:18:\"adapt_height_speed\";d:0.5;s:10:\"auto_hover\";i:1;s:10:\"auto_start\";i:1;s:11:\"breakpoints\";a:4:{s:7:\"desktop\";a:4:{s:5:\"width\";i:1200;s:10:\"max_slides\";i:2;s:11:\"move_slides\";i:1;s:6:\"margin\";i:20;}s:5:\"large\";a:4:{s:5:\"width\";i:1024;s:10:\"max_slides\";i:2;s:11:\"move_slides\";i:1;s:6:\"margin\";i:20;}s:6:\"medium\";a:4:{s:5:\"width\";i:640;s:10:\"max_slides\";i:1;s:11:\"move_slides\";i:1;s:6:\"margin\";i:10;}s:5:\"small\";a:4:{s:5:\"width\";i:480;s:10:\"max_slides\";i:1;s:11:\"move_slides\";i:1;s:6:\"margin\";i:1;}}s:18:\"continuous_sliding\";i:0;s:14:\"controls_style\";s:7:\"buttons\";s:13:\"controls_type\";s:5:\"sides\";s:6:\"effect\";s:4:\"none\";s:12:\"nav_position\";s:6:\"inside\";s:11:\"pager_style\";s:7:\"buttons\";s:10:\"pager_type\";s:4:\"none\";s:5:\"pause\";d:8;s:11:\"show_single\";a:3:{s:10:\"max_slides\";i:1;s:11:\"move_slides\";i:1;s:6:\"margin\";i:1;}s:5:\"speed\";d:1;s:18:\"stop_auto_on_click\";i:1;s:7:\"stretch\";i:0;s:4:\"type\";s:11:\"show_single\";}s:8:\"template\";s:6:\"modern\";s:17:\"template_settings\";a:3:{s:7:\"default\";a:3:{s:14:\"image_position\";s:4:\"left\";s:5:\"theme\";s:5:\"light\";s:6:\"quotes\";s:3:\"off\";}s:12:\"small-widget\";a:1:{s:14:\"image_position\";s:4:\"left\";}s:12:\"default-form\";a:1:{s:5:\"theme\";s:5:\"light\";}}s:9:\"thumbnail\";i:1;s:16:\"thumbnail_height\";i:0;s:14:\"thumbnail_size\";s:9:\"thumbnail\";s:15:\"thumbnail_width\";i:0;s:5:\"title\";i:1;s:10:\"title_link\";s:4:\"none\";s:18:\"use_default_length\";s:1:\"1\";s:16:\"use_default_more\";s:1:\"0\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'twentytwentythree', 'twentytwentythree', 0),
(3, 'Nav', 'nav', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(6, 2, 0),
(50, 3, 0),
(62, 3, 0),
(95, 3, 0),
(96, 3, 0),
(97, 3, 0),
(102, 3, 0),
(103, 3, 0),
(112, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 8);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'jcuhome'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'wp_user-settings', 'libraryContent=browse'),
(19, 1, 'wp_user-settings-time', '1680746848'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'wp_persisted_preferences', 'a:5:{s:17:\"core/edit-widgets\";a:2:{s:26:\"isComplementaryAreaVisible\";b:0;s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2023-04-12T01:59:50.997Z\";s:14:\"core/edit-post\";a:3:{s:26:\"isComplementaryAreaVisible\";b:0;s:12:\"welcomeGuide\";b:0;s:10:\"openPanels\";a:5:{i:0;s:11:\"post-status\";i:1;s:14:\"featured-image\";i:2;s:23:\"taxonomy-panel-category\";i:3;s:15:\"page-attributes\";i:4;s:16:\"discussion-panel\";}}s:14:\"core/edit-site\";a:6:{s:12:\"welcomeGuide\";b:0;s:9:\"focusMode\";b:0;s:12:\"fixedToolbar\";b:1;s:26:\"isComplementaryAreaVisible\";b:0;s:10:\"editorMode\";s:6:\"visual\";s:18:\"welcomeGuideStyles\";b:0;}s:22:\"core/customize-widgets\";a:1:{s:12:\"welcomeGuide\";b:0;}}'),
(23, 1, 'nav_menu_recently_edited', '3'),
(24, 2, 'nickname', 'antawn'),
(25, 2, 'first_name', 'Antawn'),
(26, 2, 'last_name', 'Jamison'),
(27, 2, 'description', ''),
(28, 2, 'rich_editing', 'true'),
(29, 2, 'syntax_highlighting', 'true'),
(30, 2, 'comment_shortcuts', 'false'),
(31, 2, 'admin_color', 'fresh'),
(32, 2, 'use_ssl', '0'),
(33, 2, 'show_admin_bar_front', 'true'),
(34, 2, 'locale', ''),
(35, 2, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(36, 2, 'wp_user_level', '0'),
(37, 2, 'dismissed_wp_pointers', ''),
(38, 2, 'uwp_dummy_user', '1'),
(39, 3, 'nickname', 'chynna'),
(40, 3, 'first_name', 'Chynna'),
(41, 3, 'last_name', 'Phillips'),
(42, 3, 'description', ''),
(43, 3, 'rich_editing', 'true'),
(44, 3, 'syntax_highlighting', 'true'),
(45, 3, 'comment_shortcuts', 'false'),
(46, 3, 'admin_color', 'fresh'),
(47, 3, 'use_ssl', '0'),
(48, 3, 'show_admin_bar_front', 'true'),
(49, 3, 'locale', ''),
(50, 3, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(51, 3, 'wp_user_level', '0'),
(52, 3, 'dismissed_wp_pointers', ''),
(53, 3, 'uwp_dummy_user', '1'),
(54, 4, 'nickname', 'kiki'),
(55, 4, 'first_name', 'Kiki'),
(56, 4, 'last_name', 'Cuyler'),
(57, 4, 'description', ''),
(58, 4, 'rich_editing', 'true'),
(59, 4, 'syntax_highlighting', 'true'),
(60, 4, 'comment_shortcuts', 'false'),
(61, 4, 'admin_color', 'fresh'),
(62, 4, 'use_ssl', '0'),
(63, 4, 'show_admin_bar_front', 'true'),
(64, 4, 'locale', ''),
(65, 4, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(66, 4, 'wp_user_level', '0'),
(67, 4, 'dismissed_wp_pointers', ''),
(68, 4, 'uwp_dummy_user', '1'),
(69, 5, 'nickname', 'malivai'),
(70, 5, 'first_name', 'MaliVai'),
(71, 5, 'last_name', 'Washington'),
(72, 5, 'description', ''),
(73, 5, 'rich_editing', 'true'),
(74, 5, 'syntax_highlighting', 'true'),
(75, 5, 'comment_shortcuts', 'false'),
(76, 5, 'admin_color', 'fresh'),
(77, 5, 'use_ssl', '0'),
(78, 5, 'show_admin_bar_front', 'true'),
(79, 5, 'locale', ''),
(80, 5, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(81, 5, 'wp_user_level', '0'),
(82, 5, 'dismissed_wp_pointers', ''),
(83, 5, 'uwp_dummy_user', '1'),
(84, 6, 'nickname', 'matraca'),
(85, 6, 'first_name', 'Matraca'),
(86, 6, 'last_name', 'Berg'),
(87, 6, 'description', ''),
(88, 6, 'rich_editing', 'true'),
(89, 6, 'syntax_highlighting', 'true'),
(90, 6, 'comment_shortcuts', 'false'),
(91, 6, 'admin_color', 'fresh'),
(92, 6, 'use_ssl', '0'),
(93, 6, 'show_admin_bar_front', 'true'),
(94, 6, 'locale', ''),
(95, 6, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(96, 6, 'wp_user_level', '0'),
(97, 6, 'dismissed_wp_pointers', ''),
(98, 6, 'uwp_dummy_user', '1'),
(99, 7, 'nickname', 'ron'),
(100, 7, 'first_name', 'Ron'),
(101, 7, 'last_name', 'Faucheux'),
(102, 7, 'description', ''),
(103, 7, 'rich_editing', 'true'),
(104, 7, 'syntax_highlighting', 'true'),
(105, 7, 'comment_shortcuts', 'false'),
(106, 7, 'admin_color', 'fresh'),
(107, 7, 'use_ssl', '0'),
(108, 7, 'show_admin_bar_front', 'true'),
(109, 7, 'locale', ''),
(110, 7, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(111, 7, 'wp_user_level', '0'),
(112, 7, 'dismissed_wp_pointers', ''),
(113, 7, 'uwp_dummy_user', '1'),
(114, 8, 'nickname', 'michellie'),
(115, 8, 'first_name', 'Michellie'),
(116, 8, 'last_name', 'Jones'),
(117, 8, 'description', ''),
(118, 8, 'rich_editing', 'true'),
(119, 8, 'syntax_highlighting', 'true'),
(120, 8, 'comment_shortcuts', 'false'),
(121, 8, 'admin_color', 'fresh'),
(122, 8, 'use_ssl', '0'),
(123, 8, 'show_admin_bar_front', 'true'),
(124, 8, 'locale', ''),
(125, 8, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(126, 8, 'wp_user_level', '0'),
(127, 8, 'dismissed_wp_pointers', ''),
(128, 8, 'uwp_dummy_user', '1'),
(129, 9, 'nickname', 'monta'),
(130, 9, 'first_name', 'Monta'),
(131, 9, 'last_name', 'Ellis'),
(132, 9, 'description', ''),
(133, 9, 'rich_editing', 'true'),
(134, 9, 'syntax_highlighting', 'true'),
(135, 9, 'comment_shortcuts', 'false'),
(136, 9, 'admin_color', 'fresh'),
(137, 9, 'use_ssl', '0'),
(138, 9, 'show_admin_bar_front', 'true'),
(139, 9, 'locale', ''),
(140, 9, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(141, 9, 'wp_user_level', '0'),
(142, 9, 'dismissed_wp_pointers', ''),
(143, 9, 'uwp_dummy_user', '1'),
(144, 10, 'nickname', 'picabo'),
(145, 10, 'first_name', 'Picabo'),
(146, 10, 'last_name', 'Street'),
(147, 10, 'description', ''),
(148, 10, 'rich_editing', 'true'),
(149, 10, 'syntax_highlighting', 'true'),
(150, 10, 'comment_shortcuts', 'false'),
(151, 10, 'admin_color', 'fresh'),
(152, 10, 'use_ssl', '0'),
(153, 10, 'show_admin_bar_front', 'true'),
(154, 10, 'locale', ''),
(155, 10, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(156, 10, 'wp_user_level', '0'),
(157, 10, 'dismissed_wp_pointers', ''),
(158, 10, 'uwp_dummy_user', '1'),
(159, 11, 'nickname', 'ralph'),
(160, 11, 'first_name', 'Ralph'),
(161, 11, 'last_name', 'Fiennes'),
(162, 11, 'description', ''),
(163, 11, 'rich_editing', 'true'),
(164, 11, 'syntax_highlighting', 'true'),
(165, 11, 'comment_shortcuts', 'false'),
(166, 11, 'admin_color', 'fresh'),
(167, 11, 'use_ssl', '0'),
(168, 11, 'show_admin_bar_front', 'true'),
(169, 11, 'locale', ''),
(170, 11, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(171, 11, 'wp_user_level', '0'),
(172, 11, 'dismissed_wp_pointers', ''),
(173, 11, 'uwp_dummy_user', '1'),
(174, 12, 'nickname', 'seamus'),
(175, 12, 'first_name', 'Seamus'),
(176, 12, 'last_name', ''),
(177, 12, 'description', ''),
(178, 12, 'rich_editing', 'true'),
(179, 12, 'syntax_highlighting', 'true'),
(180, 12, 'comment_shortcuts', 'false'),
(181, 12, 'admin_color', 'fresh'),
(182, 12, 'use_ssl', '0'),
(183, 12, 'show_admin_bar_front', 'true'),
(184, 12, 'locale', ''),
(185, 12, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(186, 12, 'wp_user_level', '0'),
(187, 12, 'dismissed_wp_pointers', ''),
(188, 12, 'uwp_dummy_user', '1'),
(189, 13, 'nickname', 'shan'),
(190, 13, 'first_name', 'Shan'),
(191, 13, 'last_name', 'Foster'),
(192, 13, 'description', ''),
(193, 13, 'rich_editing', 'true'),
(194, 13, 'syntax_highlighting', 'true'),
(195, 13, 'comment_shortcuts', 'false'),
(196, 13, 'admin_color', 'fresh'),
(197, 13, 'use_ssl', '0'),
(198, 13, 'show_admin_bar_front', 'true'),
(199, 13, 'locale', ''),
(200, 13, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(201, 13, 'wp_user_level', '0'),
(202, 13, 'dismissed_wp_pointers', ''),
(203, 13, 'uwp_dummy_user', '1'),
(204, 14, 'nickname', 'siobhan'),
(205, 14, 'first_name', 'Siobhan'),
(206, 14, 'last_name', ''),
(207, 14, 'description', ''),
(208, 14, 'rich_editing', 'true'),
(209, 14, 'syntax_highlighting', 'true'),
(210, 14, 'comment_shortcuts', 'false'),
(211, 14, 'admin_color', 'fresh'),
(212, 14, 'use_ssl', '0'),
(213, 14, 'show_admin_bar_front', 'true'),
(214, 14, 'locale', ''),
(215, 14, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(216, 14, 'wp_user_level', '0'),
(217, 14, 'dismissed_wp_pointers', ''),
(218, 14, 'uwp_dummy_user', '1'),
(219, 15, 'nickname', 'stephen'),
(220, 15, 'first_name', 'Stephen'),
(221, 15, 'last_name', 'Curry'),
(222, 15, 'description', ''),
(223, 15, 'rich_editing', 'true'),
(224, 15, 'syntax_highlighting', 'true'),
(225, 15, 'comment_shortcuts', 'false'),
(226, 15, 'admin_color', 'fresh'),
(227, 15, 'use_ssl', '0'),
(228, 15, 'show_admin_bar_front', 'true'),
(229, 15, 'locale', ''),
(230, 15, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(231, 15, 'wp_user_level', '0'),
(232, 15, 'dismissed_wp_pointers', ''),
(233, 15, 'uwp_dummy_user', '1'),
(234, 16, 'nickname', 'wynonna'),
(235, 16, 'first_name', 'Wynonna'),
(236, 16, 'last_name', 'Judd'),
(237, 16, 'description', ''),
(238, 16, 'rich_editing', 'true'),
(239, 16, 'syntax_highlighting', 'true'),
(240, 16, 'comment_shortcuts', 'false'),
(241, 16, 'admin_color', 'fresh'),
(242, 16, 'use_ssl', '0'),
(243, 16, 'show_admin_bar_front', 'true'),
(244, 16, 'locale', ''),
(245, 16, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(246, 16, 'wp_user_level', '0'),
(247, 16, 'dismissed_wp_pointers', ''),
(248, 16, 'uwp_dummy_user', '1'),
(249, 17, 'nickname', 'john'),
(250, 17, 'first_name', 'John'),
(251, 17, 'last_name', 'Caius'),
(252, 17, 'description', ''),
(253, 17, 'rich_editing', 'true'),
(254, 17, 'syntax_highlighting', 'true'),
(255, 17, 'comment_shortcuts', 'false'),
(256, 17, 'admin_color', 'fresh'),
(257, 17, 'use_ssl', '0'),
(258, 17, 'show_admin_bar_front', 'true'),
(259, 17, 'locale', ''),
(260, 17, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(261, 17, 'wp_user_level', '0'),
(262, 17, 'dismissed_wp_pointers', ''),
(263, 17, 'uwp_dummy_user', '1'),
(264, 18, 'nickname', 'thomas'),
(265, 18, 'first_name', 'Thomas'),
(266, 18, 'last_name', 'Carew'),
(267, 18, 'description', ''),
(268, 18, 'rich_editing', 'true'),
(269, 18, 'syntax_highlighting', 'true'),
(270, 18, 'comment_shortcuts', 'false'),
(271, 18, 'admin_color', 'fresh'),
(272, 18, 'use_ssl', '0'),
(273, 18, 'show_admin_bar_front', 'true'),
(274, 18, 'locale', ''),
(275, 18, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(276, 18, 'wp_user_level', '0'),
(277, 18, 'dismissed_wp_pointers', ''),
(278, 18, 'uwp_dummy_user', '1'),
(279, 19, 'nickname', 'jason'),
(280, 19, 'first_name', 'Jason'),
(281, 19, 'last_name', 'Chaffetz'),
(282, 19, 'description', ''),
(283, 19, 'rich_editing', 'true'),
(284, 19, 'syntax_highlighting', 'true'),
(285, 19, 'comment_shortcuts', 'false'),
(286, 19, 'admin_color', 'fresh'),
(287, 19, 'use_ssl', '0'),
(288, 19, 'show_admin_bar_front', 'true'),
(289, 19, 'locale', ''),
(290, 19, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(291, 19, 'wp_user_level', '0'),
(292, 19, 'dismissed_wp_pointers', ''),
(293, 19, 'uwp_dummy_user', '1'),
(294, 20, 'nickname', 'mamah'),
(295, 20, 'first_name', 'Mamah'),
(296, 20, 'last_name', 'Cheney'),
(297, 20, 'description', ''),
(298, 20, 'rich_editing', 'true'),
(299, 20, 'syntax_highlighting', 'true'),
(300, 20, 'comment_shortcuts', 'false'),
(301, 20, 'admin_color', 'fresh'),
(302, 20, 'use_ssl', '0'),
(303, 20, 'show_admin_bar_front', 'true'),
(304, 20, 'locale', ''),
(305, 20, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(306, 20, 'wp_user_level', '0'),
(307, 20, 'dismissed_wp_pointers', ''),
(308, 20, 'uwp_dummy_user', '1'),
(309, 21, 'nickname', 'cecelia'),
(310, 21, 'first_name', 'Cecelia'),
(311, 21, 'last_name', 'Cichan'),
(312, 21, 'description', ''),
(313, 21, 'rich_editing', 'true'),
(314, 21, 'syntax_highlighting', 'true'),
(315, 21, 'comment_shortcuts', 'false'),
(316, 21, 'admin_color', 'fresh'),
(317, 21, 'use_ssl', '0'),
(318, 21, 'show_admin_bar_front', 'true'),
(319, 21, 'locale', ''),
(320, 21, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(321, 21, 'wp_user_level', '0'),
(322, 21, 'dismissed_wp_pointers', ''),
(323, 21, 'uwp_dummy_user', '1'),
(324, 22, 'nickname', 'dan'),
(325, 22, 'first_name', 'Dan'),
(326, 22, 'last_name', 'Cortese'),
(327, 22, 'description', ''),
(328, 22, 'rich_editing', 'true'),
(329, 22, 'syntax_highlighting', 'true'),
(330, 22, 'comment_shortcuts', 'false'),
(331, 22, 'admin_color', 'fresh'),
(332, 22, 'use_ssl', '0'),
(333, 22, 'show_admin_bar_front', 'true'),
(334, 22, 'locale', ''),
(335, 22, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(336, 22, 'wp_user_level', '0'),
(337, 22, 'dismissed_wp_pointers', ''),
(338, 22, 'uwp_dummy_user', '1'),
(339, 23, 'nickname', 'vernon'),
(340, 23, 'first_name', 'Vernon'),
(341, 23, 'last_name', 'Dahmer'),
(342, 23, 'description', ''),
(343, 23, 'rich_editing', 'true'),
(344, 23, 'syntax_highlighting', 'true'),
(345, 23, 'comment_shortcuts', 'false'),
(346, 23, 'admin_color', 'fresh'),
(347, 23, 'use_ssl', '0'),
(348, 23, 'show_admin_bar_front', 'true'),
(349, 23, 'locale', ''),
(350, 23, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(351, 23, 'wp_user_level', '0'),
(352, 23, 'dismissed_wp_pointers', ''),
(353, 23, 'uwp_dummy_user', '1'),
(354, 24, 'nickname', 'andre'),
(355, 24, 'first_name', 'Andre'),
(356, 24, 'last_name', 'Dubus'),
(357, 24, 'description', ''),
(358, 24, 'rich_editing', 'true'),
(359, 24, 'syntax_highlighting', 'true'),
(360, 24, 'comment_shortcuts', 'false'),
(361, 24, 'admin_color', 'fresh'),
(362, 24, 'use_ssl', '0'),
(363, 24, 'show_admin_bar_front', 'true'),
(364, 24, 'locale', ''),
(365, 24, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(366, 24, 'wp_user_level', '0'),
(367, 24, 'dismissed_wp_pointers', ''),
(368, 24, 'uwp_dummy_user', '1'),
(369, 25, 'nickname', 'justin'),
(370, 25, 'first_name', 'Justin'),
(371, 25, 'last_name', 'Duchscherer'),
(372, 25, 'description', ''),
(373, 25, 'rich_editing', 'true'),
(374, 25, 'syntax_highlighting', 'true'),
(375, 25, 'comment_shortcuts', 'false'),
(376, 25, 'admin_color', 'fresh'),
(377, 25, 'use_ssl', '0'),
(378, 25, 'show_admin_bar_front', 'true'),
(379, 25, 'locale', ''),
(380, 25, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(381, 25, 'wp_user_level', '0'),
(382, 25, 'dismissed_wp_pointers', ''),
(383, 25, 'uwp_dummy_user', '1'),
(384, 26, 'nickname', 'keir'),
(385, 26, 'first_name', 'Keir'),
(386, 26, 'last_name', 'Dullea'),
(387, 26, 'description', ''),
(388, 26, 'rich_editing', 'true'),
(389, 26, 'syntax_highlighting', 'true'),
(390, 26, 'comment_shortcuts', 'false'),
(391, 26, 'admin_color', 'fresh'),
(392, 26, 'use_ssl', '0'),
(393, 26, 'show_admin_bar_front', 'true'),
(394, 26, 'locale', ''),
(395, 26, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(396, 26, 'wp_user_level', '0'),
(397, 26, 'dismissed_wp_pointers', ''),
(398, 26, 'uwp_dummy_user', '1'),
(399, 1, 'session_tokens', 'a:3:{s:64:\"f016fb3be7cd508cde5154e33bb208a34cfcea84af76ee2456f66541c2058761\";a:4:{s:10:\"expiration\";i:1681437259;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15\";s:5:\"login\";i:1681264459;}s:64:\"57c1065c6025773618af00b4f1ba88d3843892d05fb2bb380aba92e7bc531a49\";a:4:{s:10:\"expiration\";i:1681480005;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15\";s:5:\"login\";i:1681307205;}s:64:\"d557682f469b5931bbbe8a7ffdda6239911831cb36a7fbf759e3ff933c13f4a9\";a:4:{s:10:\"expiration\";i:1681519614;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15\";s:5:\"login\";i:1681346814;}}'),
(400, 1, 'ur_first_access', '1');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'jcuhome', '$P$BZ9eMBP7Ri2R7yo5hDdFlcqB0nA/gL0', 'jcuhome', 'phuclan.phan@my.jcu.edu.au', 'http://localhost/jcubhomefinder', '2023-04-06 01:57:04', '', 0, 'jcuhome'),
(2, 'antawn', '$P$BKOrrwAeQ1KoeRC6nPtMSweT4jxbt4.', 'antawn', 'uwp.dummy.user+1@gmail.com', '', '2023-03-28 17:06:39', '', 0, 'Antawn Jamison'),
(3, 'chynna', '$P$BKkQ3Jsdltc/BFMfii3FAEwnFfPwQ70', 'chynna', 'uwp.dummy.user+2@gmail.com', '', '2023-04-09 01:16:51', '', 0, 'Chynna Phillips'),
(4, 'kiki', '$P$BuiMXlrtDZAIySFhXV5f6Q/nWsztNX/', 'kiki', 'uwp.dummy.user+3@gmail.com', '', '2023-04-06 03:28:21', '', 0, 'Kiki Cuyler'),
(5, 'malivai', '$P$B/uz1UDqhn.50MgXJOYVfBRSDZ080c0', 'malivai', 'uwp.dummy.user+4@gmail.com', '', '2023-03-14 11:34:28', '', 0, 'MaliVai Washington'),
(6, 'matraca', '$P$Bi1jtA4ucAjuNdrQ4MO4VQ0VVKc7cF1', 'matraca', 'uwp.dummy.user+5@gmail.com', '', '2023-04-06 05:12:28', '', 0, 'Matraca Berg'),
(7, 'ron', '$P$BEpB4hwJT/Rugn/jcmZNaNDnqtuIF8/', 'ron', 'uwp.dummy.user+6@gmail.com', '', '2023-03-23 08:04:08', '', 0, 'Ron Faucheux'),
(8, 'michellie', '$P$BOezV31nkhEDNwUHRFPWbrg5h1ARZ40', 'michellie', 'uwp.dummy.user+7@gmail.com', '', '2023-04-02 03:37:28', '', 0, 'Michellie Jones'),
(9, 'monta', '$P$BPWwgG.1r79hw.m1U/ARdlYaVqIyG1/', 'monta', 'uwp.dummy.user+8@gmail.com', '', '2023-03-27 04:21:37', '', 0, 'Monta Ellis'),
(10, 'picabo', '$P$BDMXPFBHya0nJoaxKBtr5b3zHb/PYi1', 'picabo', 'uwp.dummy.user+9@gmail.com', '', '2023-03-31 10:28:57', '', 0, 'Picabo Street'),
(11, 'ralph', '$P$BMwiVwQjfhOk0K4gTP7TGcLr9ShH3b1', 'ralph', 'uwp.dummy.user+10@gmail.com', '', '2023-03-09 19:45:19', '', 0, 'Ralph Fiennes'),
(12, 'seamus', '$P$BtmtBM2qDPp5eqrk5DCdzaQU9Bq6/s.', 'seamus', 'uwp.dummy.user+11@gmail.com', '', '2023-03-15 06:34:58', '', 0, 'Seamus'),
(13, 'shan', '$P$BXBJ8vKP/eGfapTBYZ4d7HwPpmlExV1', 'shan', 'uwp.dummy.user+12@gmail.com', '', '2023-03-13 22:53:07', '', 0, 'Shan Foster'),
(14, 'siobhan', '$P$BJ8jkGEpCgZ/Hw2T3loQrGs.1eB8Lm.', 'siobhan', 'uwp.dummy.user+13@gmail.com', '', '2023-03-22 20:37:45', '', 0, 'Siobhan'),
(15, 'stephen', '$P$BlFXxof7i6BOkHG23euj59.JbV0Wsw1', 'stephen', 'uwp.dummy.user+14@gmail.com', '', '2023-03-31 20:41:45', '', 0, 'Stephen Curry'),
(16, 'wynonna', '$P$BobENjhWnmBLvLsVlyv66hgH6cV4Fu1', 'wynonna', 'uwp.dummy.user+15@gmail.com', '', '2023-03-17 14:22:49', '', 0, 'Wynonna Judd'),
(17, 'john', '$P$B8O571FTxOkRjASXfbwHMD0eXoa7iS/', 'john', 'uwp.dummy.user+16@gmail.com', '', '2023-03-22 06:46:34', '', 0, 'John Caius'),
(18, 'thomas', '$P$BXN0iLfO8QqXl96TDvIXyyUMgQZ8if1', 'thomas', 'uwp.dummy.user+17@gmail.com', '', '2023-04-03 12:41:02', '', 0, 'Thomas Carew'),
(19, 'jason', '$P$BZ57j8f1LhJc6aNMwShRjkA9U4ILyR.', 'jason', 'uwp.dummy.user+18@gmail.com', '', '2023-04-07 18:25:30', '', 0, 'Jason Chaffetz'),
(20, 'mamah', '$P$B.Q.k7bqeiTZhxyZ.nrsSt7KUEr9hf1', 'mamah', 'uwp.dummy.user+19@gmail.com', '', '2023-04-06 05:36:56', '', 0, 'Mamah Cheney'),
(21, 'cecelia', '$P$BvOwGkNqJcW3znGlv6uLWy2Od12KoT.', 'cecelia', 'uwp.dummy.user+20@gmail.com', '', '2023-03-28 09:06:36', '', 0, 'Cecelia Cichan'),
(22, 'dan', '$P$BHLM5dbL2e6cd8fUaEXBO6m6.3VJ0X0', 'dan', 'uwp.dummy.user+21@gmail.com', '', '2023-04-06 12:35:23', '', 0, 'Dan Cortese'),
(23, 'vernon', '$P$BI6rtY0BPzdTBz/YFE42GnPJqyNkNp1', 'vernon', 'uwp.dummy.user+22@gmail.com', '', '2023-03-27 10:56:32', '', 0, 'Vernon Dahmer'),
(24, 'andre', '$P$BLjQb9zYv/Ov0H4XBoNYZ8tnHDx1sW1', 'andre', 'uwp.dummy.user+23@gmail.com', '', '2023-04-10 17:50:07', '', 0, 'Andre Dubus'),
(25, 'justin', '$P$BdnawYq0sgZz3DM5RSix.pvsKcuD6.0', 'justin', 'uwp.dummy.user+24@gmail.com', '', '2023-03-28 18:47:30', '', 0, 'Justin Duchscherer'),
(26, 'keir', '$P$B0ZHY4cWvb3ZMpEiCfGpq.w.vI4iRd.', 'keir', 'uwp.dummy.user+25@gmail.com', '', '2023-04-03 07:45:06', '', 0, 'Keir Dullea');

-- --------------------------------------------------------

--
-- Table structure for table `wp_user_registration_sessions`
--

CREATE TABLE `wp_user_registration_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_uwp_form_extras`
--

CREATE TABLE `wp_uwp_form_extras` (
  `id` int(11) NOT NULL,
  `form_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `field_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'text,checkbox,radio,select,textarea',
  `site_htmlvar_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sort_order` int(11) NOT NULL,
  `is_default` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_dummy` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `expand_custom_value` int(11) DEFAULT NULL,
  `searching_range_mode` int(11) DEFAULT NULL,
  `expand_search` int(11) DEFAULT NULL,
  `front_search_title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `front_css_class` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `first_search_value` int(11) DEFAULT NULL,
  `first_search_text` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `last_search_text` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `search_min_value` int(11) DEFAULT NULL,
  `search_max_value` int(11) DEFAULT NULL,
  `search_diff_value` int(11) DEFAULT NULL,
  `search_condition` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `field_input_type` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `field_data_type` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_uwp_form_extras`
--

INSERT INTO `wp_uwp_form_extras` (`id`, `form_type`, `field_type`, `site_htmlvar_name`, `sort_order`, `is_default`, `is_dummy`, `expand_custom_value`, `searching_range_mode`, `expand_search`, `front_search_title`, `front_css_class`, `first_search_value`, `first_search_text`, `last_search_text`, `search_min_value`, `search_max_value`, `search_diff_value`, `search_condition`, `field_input_type`, `field_data_type`, `form_id`) VALUES
(1, 'register', 'text', 'first_name', 1, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(2, 'register', 'text', 'last_name', 2, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(3, 'register', 'text', 'username', 3, '1', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(4, 'register', 'email', 'email', 4, '1', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(5, 'register', 'password', 'password', 5, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_uwp_form_fields`
--

CREATE TABLE `wp_uwp_form_fields` (
  `id` int(11) NOT NULL,
  `form_type` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `data_type` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `field_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'text,checkbox,radio,select,textarea',
  `field_type_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `site_title` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `help_text` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `htmlvar_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `default_value` text COLLATE utf8mb4_unicode_520_ci,
  `sort_order` int(11) NOT NULL,
  `option_values` text COLLATE utf8mb4_unicode_520_ci,
  `is_active` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `placeholder_value` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `for_admin_use` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_default` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_dummy` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_public` enum('0','1','2') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_required` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_register_field` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_search_field` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `is_register_only_field` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `required_msg` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `show_in` text COLLATE utf8mb4_unicode_520_ci,
  `user_roles` text COLLATE utf8mb4_unicode_520_ci,
  `extra_fields` text COLLATE utf8mb4_unicode_520_ci,
  `field_icon` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `css_class` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `decimal_point` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `validation_pattern` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `validation_msg` text COLLATE utf8mb4_unicode_520_ci,
  `form_id` int(11) NOT NULL DEFAULT '1',
  `user_sort` enum('0','1') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_uwp_form_fields`
--

INSERT INTO `wp_uwp_form_fields` (`id`, `form_type`, `data_type`, `field_type`, `field_type_key`, `site_title`, `form_label`, `help_text`, `htmlvar_name`, `default_value`, `sort_order`, `option_values`, `is_active`, `placeholder_value`, `for_admin_use`, `is_default`, `is_dummy`, `is_public`, `is_required`, `is_register_field`, `is_search_field`, `is_register_only_field`, `required_msg`, `show_in`, `user_roles`, `extra_fields`, `field_icon`, `css_class`, `decimal_point`, `validation_pattern`, `validation_msg`, `form_id`, `user_sort`) VALUES
(1, 'login', 'VARCHAR', 'text', 'text', 'Username', '', '', 'username', '', 1, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(2, 'login', 'VARCHAR', 'password', 'password', 'Password', '', '', 'password', '', 2, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(3, 'forgot', 'VARCHAR', 'email', 'email', 'Email', '', '', 'email', '', 3, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(4, 'account', 'VARCHAR', 'text', 'text', 'First Name', '', '', 'first_name', '', 4, '', '1', '', '0', '1', '0', '1', '1', '1', '1', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(5, 'account', 'VARCHAR', 'text', 'text', 'Last Name', '', '', 'last_name', '', 5, '', '1', '', '0', '1', '0', '1', '1', '1', '1', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(6, 'account', 'VARCHAR', 'text', 'text', 'Username', '', '', 'username', '', 6, '', '1', '', '0', '1', '0', '1', '1', '1', '1', '1', '', '', '', '', '', '', '', '', '', 1, '0'),
(7, 'account', 'VARCHAR', 'text', 'text', 'Display Name', '', '', 'display_name', '', 7, '', '1', '', '0', '1', '0', '1', '0', '0', '1', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(8, 'account', 'VARCHAR', 'email', 'email', 'Email', '', '', 'email', '', 8, '', '1', '', '0', '1', '0', '0', '1', '1', '1', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(9, 'account', 'TEXT', 'textarea', 'textarea', 'Bio', '', '', 'bio', '', 9, '', '1', '', '0', '0', '0', '1', '1', '0', '1', '0', '', '[users]', '', '', '', '', '', '', '', 1, '0'),
(10, 'account', 'VARCHAR', 'password', 'password', 'Password', '', '', 'password', '', 10, '', '1', '', '0', '1', '0', '0', '1', '1', '0', '1', '', '', '', 'a:1:{s:16:\"confirm_password\";s:1:\"1\";}', '', '', '', '', '', 1, '0'),
(11, 'avatar', 'TEXT', 'file', 'file', 'Avatar', '', '', 'avatar', '', 11, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(12, 'banner', 'TEXT', 'file', 'file', 'Banner', '', '', 'banner', '', 12, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(13, 'change', 'VARCHAR', 'password', 'password', 'Old Password', '', '', 'old_password', '', 13, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(14, 'change', 'VARCHAR', 'password', 'password', 'New Password', '', '', 'password', '', 14, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(15, 'change', 'VARCHAR', 'password', 'password', 'Confirm Password', '', '', 'confirm_password', '', 15, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(16, 'reset', 'VARCHAR', 'password', 'password', 'Password', '', '', 'password', '', 16, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0'),
(17, 'reset', 'VARCHAR', 'password', 'password', 'Confirm Password', '', '', 'confirm_password', '', 17, '', '1', '', '0', '1', '0', '0', '1', '0', '0', '0', '', '', '', '', '', '', '', '', '', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `wp_uwp_profile_tabs`
--

CREATE TABLE `wp_uwp_profile_tabs` (
  `id` int(11) NOT NULL,
  `form_type` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL,
  `tab_layout` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tab_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tab_level` int(11) NOT NULL,
  `tab_parent` int(11) NOT NULL,
  `tab_privacy` int(11) NOT NULL DEFAULT '0',
  `user_decided` int(11) NOT NULL DEFAULT '0',
  `tab_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tab_icon` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tab_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tab_content` text COLLATE utf8mb4_unicode_520_ci,
  `form_id` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_uwp_social_profiles`
--

CREATE TABLE `wp_uwp_social_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sha` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `profileurl` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `websiteurl` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `photourl` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `displayname` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `age` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `birthday` int(11) NOT NULL,
  `birthmonth` int(11) NOT NULL,
  `birthyear` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `emailverified` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `phone` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `country` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `region` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zip` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_uwp_usermeta`
--

CREATE TABLE `wp_uwp_usermeta` (
  `user_id` int(20) NOT NULL,
  `user_ip` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_privacy` text COLLATE utf8mb4_unicode_520_ci,
  `tabs_privacy` text COLLATE utf8mb4_unicode_520_ci,
  `username` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `avatar_thumb` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `banner_thumb` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_url` text COLLATE utf8mb4_unicode_520_ci,
  `bio` text COLLATE utf8mb4_unicode_520_ci,
  `avatar` text COLLATE utf8mb4_unicode_520_ci,
  `banner` text COLLATE utf8mb4_unicode_520_ci,
  `old_password` varchar(254) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_uwp_usermeta`
--

INSERT INTO `wp_uwp_usermeta` (`user_id`, `user_ip`, `user_privacy`, `tabs_privacy`, `username`, `email`, `first_name`, `last_name`, `avatar_thumb`, `banner_thumb`, `display_name`, `user_url`, `bio`, `avatar`, `banner`, `old_password`) VALUES
(1, '::1', NULL, NULL, 'jcuhome', 'phuclan.phan@my.jcu.edu.au', '', '', NULL, NULL, 'jcuhome', NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, 'antawn', 'uwp.dummy.user+1@gmail.com', 'Antawn', 'Jamison', NULL, NULL, 'Antawn Jamison', '', '', NULL, NULL, NULL),
(3, NULL, NULL, NULL, 'chynna', 'uwp.dummy.user+2@gmail.com', 'Chynna', 'Phillips', NULL, NULL, 'Chynna Phillips', '', '', NULL, NULL, NULL),
(4, NULL, NULL, NULL, 'kiki', 'uwp.dummy.user+3@gmail.com', 'Kiki', 'Cuyler', NULL, NULL, 'Kiki Cuyler', '', '', NULL, NULL, NULL),
(5, NULL, NULL, NULL, 'malivai', 'uwp.dummy.user+4@gmail.com', 'MaliVai', 'Washington', NULL, NULL, 'MaliVai Washington', '', '', NULL, NULL, NULL),
(6, NULL, NULL, NULL, 'matraca', 'uwp.dummy.user+5@gmail.com', 'Matraca', 'Berg', NULL, NULL, 'Matraca Berg', '', '', NULL, NULL, NULL),
(7, NULL, NULL, NULL, 'ron', 'uwp.dummy.user+6@gmail.com', 'Ron', 'Faucheux', NULL, NULL, 'Ron Faucheux', '', '', NULL, NULL, NULL),
(8, NULL, NULL, NULL, 'michellie', 'uwp.dummy.user+7@gmail.com', 'Michellie', 'Jones', NULL, NULL, 'Michellie Jones', '', '', NULL, NULL, NULL),
(9, NULL, NULL, NULL, 'monta', 'uwp.dummy.user+8@gmail.com', 'Monta', 'Ellis', NULL, NULL, 'Monta Ellis', '', '', NULL, NULL, NULL),
(10, NULL, NULL, NULL, 'picabo', 'uwp.dummy.user+9@gmail.com', 'Picabo', 'Street', NULL, NULL, 'Picabo Street', '', '', NULL, NULL, NULL),
(11, NULL, NULL, NULL, 'ralph', 'uwp.dummy.user+10@gmail.com', 'Ralph', 'Fiennes', NULL, NULL, 'Ralph Fiennes', '', '', NULL, NULL, NULL),
(12, NULL, NULL, NULL, 'seamus', 'uwp.dummy.user+11@gmail.com', 'Seamus', '', NULL, NULL, 'Seamus', '', '', NULL, NULL, NULL),
(13, NULL, NULL, NULL, 'shan', 'uwp.dummy.user+12@gmail.com', 'Shan', 'Foster', NULL, NULL, 'Shan Foster', '', '', NULL, NULL, NULL),
(14, NULL, NULL, NULL, 'siobhan', 'uwp.dummy.user+13@gmail.com', 'Siobhan', '', NULL, NULL, 'Siobhan', '', '', NULL, NULL, NULL),
(15, NULL, NULL, NULL, 'stephen', 'uwp.dummy.user+14@gmail.com', 'Stephen', 'Curry', NULL, NULL, 'Stephen Curry', '', '', NULL, NULL, NULL),
(16, NULL, NULL, NULL, 'wynonna', 'uwp.dummy.user+15@gmail.com', 'Wynonna', 'Judd', NULL, NULL, 'Wynonna Judd', '', '', NULL, NULL, NULL),
(17, NULL, NULL, NULL, 'john', 'uwp.dummy.user+16@gmail.com', 'John', 'Caius', NULL, NULL, 'John Caius', '', '', NULL, NULL, NULL),
(18, NULL, NULL, NULL, 'thomas', 'uwp.dummy.user+17@gmail.com', 'Thomas', 'Carew', NULL, NULL, 'Thomas Carew', '', '', NULL, NULL, NULL),
(19, NULL, NULL, NULL, 'jason', 'uwp.dummy.user+18@gmail.com', 'Jason', 'Chaffetz', NULL, NULL, 'Jason Chaffetz', '', '', NULL, NULL, NULL),
(20, NULL, NULL, NULL, 'mamah', 'uwp.dummy.user+19@gmail.com', 'Mamah', 'Cheney', NULL, NULL, 'Mamah Cheney', '', '', NULL, NULL, NULL),
(21, NULL, NULL, NULL, 'cecelia', 'uwp.dummy.user+20@gmail.com', 'Cecelia', 'Cichan', NULL, NULL, 'Cecelia Cichan', '', '', NULL, NULL, NULL),
(22, NULL, NULL, NULL, 'dan', 'uwp.dummy.user+21@gmail.com', 'Dan', 'Cortese', NULL, NULL, 'Dan Cortese', '', '', NULL, NULL, NULL),
(23, NULL, NULL, NULL, 'vernon', 'uwp.dummy.user+22@gmail.com', 'Vernon', 'Dahmer', NULL, NULL, 'Vernon Dahmer', '', '', NULL, NULL, NULL),
(24, NULL, NULL, NULL, 'andre', 'uwp.dummy.user+23@gmail.com', 'Andre', 'Dubus', NULL, NULL, 'Andre Dubus', '', '', NULL, NULL, NULL),
(25, NULL, NULL, NULL, 'justin', 'uwp.dummy.user+24@gmail.com', 'Justin', 'Duchscherer', NULL, NULL, 'Justin Duchscherer', '', '', NULL, NULL, NULL),
(26, NULL, NULL, NULL, 'keir', 'uwp.dummy.user+25@gmail.com', 'Keir', 'Dullea', NULL, NULL, 'Keir Dullea', '', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_uwp_user_sorting`
--

CREATE TABLE `wp_uwp_user_sorting` (
  `id` int(11) NOT NULL,
  `data_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `field_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `site_title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `htmlvar_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `field_icon` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `tab_parent` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `tab_level` int(11) NOT NULL DEFAULT '0',
  `is_active` int(11) NOT NULL DEFAULT '0',
  `is_default` int(11) NOT NULL DEFAULT '0',
  `sort` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT 'asc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_uwp_user_sorting`
--

INSERT INTO `wp_uwp_user_sorting` (`id`, `data_type`, `field_type`, `site_title`, `htmlvar_name`, `field_icon`, `sort_order`, `tab_parent`, `tab_level`, `is_active`, `is_default`, `sort`) VALUES
(1, '', 'text', 'Display Name (A-Z)', 'display_name', 'fas fa-sort-alpha-up', 1, '0', 0, 1, 1, 'asc'),
(2, '', 'text', 'Display Name (Z-A)', 'display_name', 'fas fa-sort-alpha-up', 2, '0', 0, 1, 0, 'desc'),
(3, '', 'newer', 'Newer', 'newer', 'fas fa-calendar', 3, '0', 0, 1, 0, 'asc'),
(4, '', 'older', 'Older', 'older', 'fas fa-calendar', 4, '0', 0, 1, 0, 'desc'),
(5, '', 'text', 'First Name (A-Z)', 'first_name', 'fas fa-fa-sort-alpha-up', 5, '0', 0, 1, 0, 'asc'),
(6, '', 'text', 'First Name (Z-A)', 'first_name', 'fas fa-fa-sort-alpha-up', 6, '0', 0, 1, 0, 'desc'),
(7, '', 'text', 'Last Name (A-Z)', 'last_name', 'fas fa-fa-sort-alpha-up', 7, '0', 0, 1, 0, 'asc'),
(8, '', 'text', 'Last Name (Z-A)', 'last_name', 'fas fa-fa-sort-alpha-up', 8, '0', 0, 1, 0, 'desc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_strong_views`
--
ALTER TABLE `wp_strong_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_user_registration_sessions`
--
ALTER TABLE `wp_user_registration_sessions`
  ADD PRIMARY KEY (`session_key`),
  ADD UNIQUE KEY `session_id` (`session_id`);

--
-- Indexes for table `wp_uwp_form_extras`
--
ALTER TABLE `wp_uwp_form_extras`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_uwp_form_fields`
--
ALTER TABLE `wp_uwp_form_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_uwp_profile_tabs`
--
ALTER TABLE `wp_uwp_profile_tabs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_uwp_social_profiles`
--
ALTER TABLE `wp_uwp_social_profiles`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `provider` (`provider`);

--
-- Indexes for table `wp_uwp_usermeta`
--
ALTER TABLE `wp_uwp_usermeta`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `wp_uwp_user_sorting`
--
ALTER TABLE `wp_uwp_user_sorting`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=406;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=505;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `wp_strong_views`
--
ALTER TABLE `wp_strong_views`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=401;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `wp_user_registration_sessions`
--
ALTER TABLE `wp_user_registration_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_uwp_form_extras`
--
ALTER TABLE `wp_uwp_form_extras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wp_uwp_form_fields`
--
ALTER TABLE `wp_uwp_form_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `wp_uwp_profile_tabs`
--
ALTER TABLE `wp_uwp_profile_tabs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_uwp_social_profiles`
--
ALTER TABLE `wp_uwp_social_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_uwp_user_sorting`
--
ALTER TABLE `wp_uwp_user_sorting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
